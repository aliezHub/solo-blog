title: kvm学习指南
date: '2019-12-12 00:02:35'
updated: '2019-12-12 00:03:02'
tags: [kvm]
permalink: /articles/2019/12/12/1576080154976.html
---
![](https://img.hacpai.com/bing/20190427.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

一、kvm虚拟机安装
安装依赖环境
```
# yum install -y qemu-kvm libvirt virt-install
```

查看安装情况
```
# rpm -ql qemu-kvm
# rpm -qa|grep libvirt
```

启动
```
# systemctl start libvirtd
```

检查
启动完libvirtd之后，会给启动一个新的网卡virbr0。
```
# ifconfig
eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.8.40  netmask 255.255.255.0  broadcast 192.168.8.255
        inet6 fe80::20c:29ff:fe97:7f45  prefixlen 64  scopeid 0x20<link>
        ether 00:0c:29:97:7f:45  txqueuelen 1000  (Ethernet)
        RX packets 3862925  bytes 5557973351 (5.1 GiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 1290148  bytes 90331682 (86.1 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 32  bytes 2592 (2.5 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 32  bytes 2592 (2.5 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

virbr0: flags=4099<UP,BROADCAST,MULTICAST>  mtu 1500
        inet 192.168.122.1  netmask 255.255.255.0  broadcast 192.168.122.255
        ether 52:54:00:19:3a:00  txqueuelen 1000  (Ethernet)
        RX packets 0  bytes 0 (0.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 0  bytes 0 (0.0 B)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
```

会默认启动一个dnsmasq的服务
```
# ps -ef|grep dnsmasq
nobody    47159      1  0 14:21 ?        00:00:00 /usr/sbin/dnsmasq --conf-file=/var/lib/libvirt/dnsmasq/default.conf --leasefile-ro --dhcp-script=/usr/libexec/libvirt_leaseshelper
root      47160  47159  0 14:21 ?        00:00:00 /usr/sbin/dnsmasq --conf-file=/var/lib/libvirt/dnsmasq/default.conf --leasefile-ro --dhcp-script=/usr/libexec/libvirt_leaseshelper
root      47221  47009  0 14:23 pts/1    00:00:00 grep --color=auto dnsmasq
```

还启动了一个libvirtd的服务
```
# ps -ef|grep libvirt
root      47034      1  0 14:21 ?        00:00:00 /usr/sbin/libvirtd
nobody    47159      1  0 14:21 ?        00:00:00 /usr/sbin/dnsmasq --conf-file=/var/lib/libvirt/dnsmasq/default.conf --leasefile-ro --dhcp-script=/usr/libexec/libvirt_leaseshelper
root      47160  47159  0 14:21 ?        00:00:00 /usr/sbin/dnsmasq --conf-file=/var/lib/libvirt/dnsmasq/default.conf --leasefile-ro --dhcp-script=/usr/libexec/libvirt_leaseshelper
root      47223  47009  0 14:24 pts/1    00:00:00 grep --color=auto libvirt
```

并生成了一个default.conf的配置文件
```
# cat /var/lib/libvirt/dnsmasq/default.conf
##WARNING:  THIS IS AN AUTO-GENERATED FILE. CHANGES TO IT ARE LIKELY TO BE
##OVERWRITTEN AND LOST.  Changes to this configuration should be made using:
##    virsh net-edit default
## or other application using the libvirt API.
##
## dnsmasq conf file created by libvirt
strict-order
pid-file=/var/run/libvirt/network/default.pid
except-interface=lo
bind-dynamic
interface=virbr0
dhcp-range=192.168.122.2,192.168.122.254
dhcp-no-override
dhcp-authoritative
dhcp-lease-max=253
dhcp-hostsfile=/var/lib/libvirt/dnsmasq/default.hostsfile
addn-hosts=/var/lib/libvirt/dnsmasq/default.addnhosts
```


创建一个kvm虚拟盘

```
# qemu-img create -f raw /data/Centos-7-x86_64.raw 5G
# -f：指定虚拟盘格式
# 创建一个大小是5G的raw格式的虚拟盘，位置在/data下，名称为Centos-7-x86_64.raw
```

```
# file Centos-7-x86_64.raw 
Centos-7-x86_64.raw: data
```

在执行下面的命令之前，先打开vnc，提前做好准备。
![clipboard.png](https://img.hacpai.com/file/2019/12/clipboard-ca9bb2df.png)

建虚拟机
```
# virt-install --virt-type kvm --name CentOS-7_X86_64 --ram 1024 --cdrom=/data/CentOS-7-x86_64-DVD-1708.iso --disk path=/data/Centos-7-x86_64.raw  --network network=default --graphics vnc,listen=0.0.0.0 --noautoconsole

开始安装......
域安装仍在进行。您可以重新连接
到控制台以便完成安装进程。
```

此时迅速点击vnc的connect。
![clipboard01.png](https://img.hacpai.com/file/2019/12/clipboard01-606f8b65.png)

修改网卡名为eth0,光标移动到install Centos7，然后tab,输入net.ifnames=0 biosdevname=0,然后回车即可。
![clipboard02.png](https://img.hacpai.com/file/2019/12/clipboard02-e2d49ca9.png)

接下来的过程就和服务器装系统是一样的步骤。
```
# ps -ef|grep qemu
qemu      10822      1 16 14:33 ?        00:01:44 /usr/libexec/qemu-kvm -name CentOS-7_X86_64 -S -machine pc-i440fx-rhel7.0.0,accel=kvm,usb=off,dump-guest-core=off -cpu Broadwell-IBRS,-hle,-rtm -m 1024 -realtime mlock=off -smp 1,sockets=1,cores=1,threads=1 -uuid f309f620-e9a1-4dd8-91e6-6a66b15d97c0 -no-user-config -nodefaults -chardev socket,id=charmonitor,path=/var/lib/libvirt/qemu/domain-2-CentOS-7_X86_64/monitor.sock,server,nowait -mon chardev=charmonitor,id=monitor,mode=control -rtc base=utc,driftfix=slew -global kvm-pit.lost_tick_policy=delay -no-hpet -no-reboot -global PIIX4_PM.disable_s3=1 -global PIIX4_PM.disable_s4=1 -boot strict=on -device ich9-usb-ehci1,id=usb,bus=pci.0,addr=0x4.0x7 -device ich9-usb-uhci1,masterbus=usb.0,firstport=0,bus=pci.0,multifunction=on,addr=0x4 -device ich9-usb-uhci2,masterbus=usb.0,firstport=2,bus=pci.0,addr=0x4.0x1 -device ich9-usb-uhci3,masterbus=usb.0,firstport=4,bus=pci.0,addr=0x4.0x2 -device virtio-serial-pci,id=virtio-serial0,bus=pci.0,addr=0x5 -drive file=/data/Centos-7-x86_64.raw,format=raw,if=none,id=drive-virtio-disk0 -device virtio-blk-pci,scsi=off,bus=pci.0,addr=0x6,drive=drive-virtio-disk0,id=virtio-disk0,bootindex=2 -drive file=/data/CentOS-7-x86_64-DVD-1708.iso,format=raw,if=none,id=drive-ide0-0-0,readonly=on -device ide-cd,bus=ide.0,unit=0,drive=drive-ide0-0-0,id=ide0-0-0,bootindex=1 -netdev tap,fd=26,id=hostnet0,vhost=on,vhostfd=28 -device virtio-net-pci,netdev=hostnet0,id=net0,mac=52:54:00:77:9e:21,bus=pci.0,addr=0x3 -chardev pty,id=charserial0 -device isa-serial,chardev=charserial0,id=serial0 -chardev socket,id=charchannel0,path=/var/lib/libvirt/qemu/channel/target/domain-2-CentOS-7_X86_64/org.qem.guest_agent.0,server,nowait -device virtserialport,bus=virtio-serial0.0,nr=1,chardev=charchannel0,id=channel0,name=org.qemu.guest_agent.0 -device usb-tablet,id=input0,bus=usb.0,port=1 -vnc 0.0.0.0:0 -vga cirrus -device virtio-balloon-pci,id=balloon0,bus=pci.0,addr=0x7 -object rng-random,id=objrng0,filename=/dev/urandom -device virtio-rng-pci,rng=objrng0,id=rng0,bus=pci.0,addr=0x8 -msg timestamp=on
```

查看运行的kvm虚拟机列表。
```
# virsh list
 Id    名称                         状态
----------------------------------------------------
 2     CentOS-7_X86_64                running
```

查看virsh命令是怎么安装的。
```
# whereis virsh
virsh: /usr/bin/virsh /usr/share/man/man1/virsh.1.gz
# rpm -qf /usr/bin/virsh
libvirt-client-4.5.0-10.el7_6.12.x86_64
```

虚拟的管理
1.网卡的UUID删除掉。
2.默认的安装软件，比如Java、nginx、tomcat、php等。
3.iptables和selinux关闭。
4.默认的root密码。
当vnc中的虚拟机安装完毕之后，点击重启，这个虚拟机就关闭了。
```
# virsh list --all
 Id    名称                         状态
----------------------------------------------------
 -     CentOS-7_X86_64                关闭
```

启动kvm虚拟机
```
# virsh start CentOS-7_X86_64
域 CentOS-7_X86_64 已开始
```

```
# virsh list
 Id    名称                         状态
----------------------------------------------------
 3     CentOS-7_X86_64                running
```

再次用vnc连接我们的kvm虚拟机
![clipboard03.png](https://img.hacpai.com/file/2019/12/clipboard03-d20e0525.png)

下面的操作在vnc里面操作
修改网卡
```
# vi /etc/sysconfig/network-scripts/ifcfg-eth0
TYPE="Ethernet"
BOOTPROTO="dhcp"
NAME="eth0"
DEVICE="eth0"
ONBOOT="yes"
```

修改完，重启网卡
```
# systemctl restart network
```

查看网络状况
![clipboard04.png](https://img.hacpai.com/file/2019/12/clipboard04-1b96d4d9.png)

给分配了一个192.168.122.107的ip，能上外网。
接下来就是安装一些依赖包了
```
# yum install vim wget net-tools -y
```

在192.168.8.40上面查看kvm虚拟机是怎么上外网的
```
# ifconfig
eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.8.40  netmask 255.255.255.0  broadcast 192.168.8.255
        inet6 fe80::20c:29ff:fe97:7f45  prefixlen 64  scopeid 0x20<link>
        ether 00:0c:29:97:7f:45  txqueuelen 1000  (Ethernet)
        RX packets 86414  bytes 27818172 (26.5 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 59397  bytes 17483562 (16.6 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 33  bytes 2668 (2.6 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 33  bytes 2668 (2.6 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

virbr0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.122.1  netmask 255.255.255.0  broadcast 192.168.122.255
        ether 52:54:00:19:3a:00  txqueuelen 1000  (Ethernet)
        RX packets 5624  bytes 237024 (231.4 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 7001  bytes 23018198 (21.9 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

vnet0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet6 fe80::fc54:ff:fe77:9e21  prefixlen 64  scopeid 0x20<link>
        ether fe:54:00:77:9e:21  txqueuelen 1000  (Ethernet)
        RX packets 5536  bytes 308078 (300.8 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 7316  bytes 23031756 (21.9 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
```

```
# iptables -t nat -vnL
Chain PREROUTING (policy ACCEPT 197 packets, 14716 bytes)
 pkts bytes target     prot opt in     out     source               destination         

Chain INPUT (policy ACCEPT 53 packets, 4276 bytes)
 pkts bytes target     prot opt in     out     source               destination         

Chain OUTPUT (policy ACCEPT 167 packets, 12898 bytes)
 pkts bytes target     prot opt in     out     source               destination         

Chain POSTROUTING (policy ACCEPT 167 packets, 12898 bytes)
 pkts bytes target     prot opt in     out     source               destination         
    0     0 RETURN     all  --  *      *       192.168.122.0/24     224.0.0.0/24        
    0     0 RETURN     all  --  *      *       192.168.122.0/24     255.255.255.255     
   32  1920 MASQUERADE  tcp  --  *      *       192.168.122.0/24    !192.168.122.0/24     masq ports: 1024-65535
  111  8436 MASQUERADE  udp  --  *      *       192.168.122.0/24    !192.168.122.0/24     masq ports: 1024-65535
    1    84 MASQUERADE  all  --  *      *       192.168.122.0/24    !192.168.122.0/24    
```

由于现在是使用的nat，网络传输效率会大打折扣，而且我们在外面是连接不到kvm的虚拟机里面的。我们可以自己创建一个桥接网卡，直接分配和宿主机一个网段的ip地址。
先把我们刚才创建的kvm虚拟机关机，shutdown -h now
创建桥接网卡
```
# brctl show
bridge name	bridge id		STP enabled	interfaces
virbr0		8000.525400193a00	yes		virbr0-nic
```

```
# rpm -q bridge-utils
bridge-utils-1.5-9.el7.x86_64
```

```
# brctl addbr br0              #br0为创建的桥接网卡名称，可以随便起
```
由于创建的桥接网卡还没启动，所以此时用ifconfig是查看不到br0这块网卡的信息的。
```
# brctl show
bridge name	bridge id		STP enabled	interfaces
br0		8000.000000000000	no		
virbr0		8000.525400193a00	yes		virbr0-nic
```

接下来我们将宿主机的eth0桥接到br0上。
```
# brctl addif br0 eth0
```


执行完这条命令之后我们会发现网络中断了。所以在物理机这么操作是不可以的，我们可以写个脚本直接执行。
![clipboard05.png](https://img.hacpai.com/file/2019/12/clipboard05-1f287ccf.png)

现在我们需要将eth0的ip给去掉，将原来eth0的ip放到br0上面。
删除eth0的ip
```
# ip addr del dev eth0 192.168.8.40/24
```

把eth0的ip加到br0上
```
# ifconfig br0 192.168.8.40/24 up
```

添加默认路由
```
# route add default gw 192.168.8.2
```

现在查看ip
![clipboard06.png](https://img.hacpai.com/file/2019/12/clipboard06-5134fe62.png)

此时我们就可以在外部通过xshell或者crt连接我们的宿主机了。
现在设置我们的kvm虚拟机使用br0的桥接网卡（kvm虚拟机默认走的是virbr0，走的是nat，外部无法连接，且性能有损耗）。
通过libvirt创建的虚拟机，其实都是通过xml文件来定义的（下面是我们创建的kvm虚拟机的xml文件）。
```
# cat /etc/libvirt/qemu/CentOS-7_X86_64.xml 
<!--
WARNING: THIS IS AN AUTO-GENERATED FILE. CHANGES TO IT ARE LIKELY TO BE
OVERWRITTEN AND LOST. Changes to this xml configuration should be made using:
  virsh edit CentOS-7_X86_64
or other application using the libvirt API.
-->

<domain type='kvm'>
  <name>CentOS-7_X86_64</name>
  <uuid>f309f620-e9a1-4dd8-91e6-6a66b15d97c0</uuid>
  <memory unit='KiB'>1048576</memory>
  <currentMemory unit='KiB'>1048576</currentMemory>
  <vcpu placement='static'>1</vcpu>
  <os>
    <type arch='x86_64' machine='pc-i440fx-rhel7.0.0'>hvm</type>
    <boot dev='hd'/>
  </os>
  <features>
    <acpi/>
    <apic/>
  </features>
  <cpu mode='custom' match='exact' check='partial'>
    <model fallback='allow'>Broadwell-noTSX-IBRS</model>
  </cpu>
  <clock offset='utc'>
    <timer name='rtc' tickpolicy='catchup'/>
    <timer name='pit' tickpolicy='delay'/>
    <timer name='hpet' present='no'/>
  </clock>
  <on_poweroff>destroy</on_poweroff>
  <on_reboot>restart</on_reboot>
  <on_crash>destroy</on_crash>
  <pm>
    <suspend-to-mem enabled='no'/>
    <suspend-to-disk enabled='no'/>
  </pm>
  <devices>
    <emulator>/usr/libexec/qemu-kvm</emulator>
    <disk type='file' device='disk'>
      <driver name='qemu' type='raw'/>
      <source file='/data/Centos-7-x86_64.raw'/>
      <target dev='vda' bus='virtio'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x06' function='0x0'/>
    </disk>
    <disk type='file' device='cdrom'>
      <driver name='qemu' type='raw'/>
      <target dev='hda' bus='ide'/>
      <readonly/>
      <address type='drive' controller='0' bus='0' target='0' unit='0'/>
    </disk>
    <controller type='usb' index='0' model='ich9-ehci1'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x7'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci1'>
      <master startport='0'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x0' multifunction='on'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci2'>
      <master startport='2'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x1'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci3'>
      <master startport='4'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x2'/>
    </controller>
    <controller type='pci' index='0' model='pci-root'/>
    <controller type='ide' index='0'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x01' function='0x1'/>
    </controller>
    <controller type='virtio-serial' index='0'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x05' function='0x0'/>
    </controller>
    <interface type='network'>
      <mac address='52:54:00:77:9e:21'/>
      <source network='default'/>
      <model type='virtio'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x03' function='0x0'/>
    </interface>
    <serial type='pty'>
      <target type='isa-serial' port='0'>
        <model name='isa-serial'/>
      </target>
    </serial>
    <console type='pty'>
      <target type='serial' port='0'/>
    </console>
    <channel type='unix'>
      <target type='virtio' name='org.qemu.guest_agent.0'/>
      <address type='virtio-serial' controller='0' bus='0' port='1'/>
    </channel>
    <input type='tablet' bus='usb'>
      <address type='usb' bus='0' port='1'/>
    </input>
    <input type='mouse' bus='ps2'/>
    <input type='keyboard' bus='ps2'/>
    <graphics type='vnc' port='-1' autoport='yes' listen='0.0.0.0'>
      <listen type='address' address='0.0.0.0'/>
    </graphics>
    <video>
      <model type='cirrus' vram='16384' heads='1' primary='yes'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x02' function='0x0'/>
    </video>
    <memballoon model='virtio'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x07' function='0x0'/>
    </memballoon>
    <rng model='virtio'>
      <backend model='random'>/dev/urandom</backend>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x08' function='0x0'/>
    </rng>
  </devices>
</domain>
```

将network模块换成bridge桥接模式。
```
# virsh edit CentOS-7_X86_64
      <interface type='bridge'>
      <mac address='52:54:00:77:9e:21'/>
      <source bridge='br0'/>
      <model type='virtio'/>
```

启动虚拟机
```
# virsh list --all
 Id    名称                         状态
----------------------------------------------------
 -     CentOS-7_X86_64                关闭
```

```
# virsh start CentOS-7_X86_64
域 CentOS-7_X86_64 已开始
```

```
# virsh list 
 Id    名称                         状态
----------------------------------------------------
 4     CentOS-7_X86_64                running
```

用vnc连接
![clipboard07.png](https://img.hacpai.com/file/2019/12/clipboard07-756f60a9.png)

发现，此时的ip已经发生了改变，之前是和virbr0一个网段的，现在是和br0是一个网段的。
如果启动发现没有给kvm虚拟机分配ip，可以手动设置一个固定的ip。
现在可以用xshell或者CRT远程连接了。
![clipboard08.png](https://img.hacpai.com/file/2019/12/clipboard08-a8dc6b53.png)

修改kvm虚拟机的cpu个数（在创建虚拟机的时候可以添加参数--vcpu 5, maxcpu=10来实现）
```
# virsh edit CentOS-7_X86_64
<domain type='kvm'>
  <name>CentOS-7_X86_64</name>
  <uuid>f309f620-e9a1-4dd8-91e6-6a66b15d97c0</uuid>
  <memory unit='KiB'>1048576</memory>
  <currentMemory unit='KiB'>1048576</currentMemory>
  <vcpu placement='static'>1</vcpu>  
```          
默认cpu是静态的，是不允许修改的，我们要是非要修改，可以把静态改成auto。cpu的个数不能超过宿主机的cpu个数。


```
# virsh edit CentOS-7_X86_64
<domain type='kvm'>
  <name>CentOS-7_X86_64</name>
  <uuid>f309f620-e9a1-4dd8-91e6-6a66b15d97c0</uuid>
  <memory unit='KiB'>1048576</memory>
  <currentMemory unit='KiB'>1048576</currentMemory>
  <vcpu placement='auto' current="1">2</vcpu>   
``` 
修改动态cpu个数，当前是1.最大是2.我们宿主机是2个cpu，不能超过宿主机的cpu个数。

其实修改完，我们的虚拟机还是只有一个cpu，我们只是修改了他可以支持热添加cpu，但是这个修改需要重启才能生效。重启之后，热添加cpu个数就不再需要重启了。
重启kvm虚拟机：
```
# virsh shutdown CentOS-7_X86_64
域 CentOS-7_X86_64 被关闭
```

```
# virsh list --all
 Id    名称                         状态
----------------------------------------------------
 -     CentOS-7_X86_64                关闭
```

```
# virsh start CentOS-7_X86_64
域 CentOS-7_X86_64 已开始
```

```
# virsh list --all
 Id    名称                         状态
----------------------------------------------------
 5     CentOS-7_X86_64                running
```

现在将kvm虚拟机的cpu个数改为2
```
# virsh setvcpus CentOS-7_X86_64 2
```

检查
![clipboard09.png](https://img.hacpai.com/file/2019/12/clipboard09-618c5e38.png)

并且cpu1为开启状态
```
# cat /sys/devices/system/cpu/cpu1/online 
1
```

两个cpu都在工作状态
```
# cat /proc/interrupts 
           CPU0       CPU1       
  0:        183          0   IO-APIC-edge      timer
  1:         10          0   IO-APIC-edge      i8042
  6:          3          0   IO-APIC-edge      floppy
  8:          0          0   IO-APIC-edge      rtc0
  9:          1          0   IO-APIC-fasteoi   acpi
 10:          0          0   IO-APIC-fasteoi   uhci_hcd:usb3, uhci_hcd:usb4
 11:         32          0   IO-APIC-fasteoi   ehci_hcd:usb1, uhci_hcd:usb2, virtio3, virtio4
 12:         15          0   IO-APIC-edge      i8042
 14:        404          0   IO-APIC-edge      ata_piix
 15:          0          0   IO-APIC-edge      ata_piix
 24:          0          0   PCI-MSI-edge      virtio2-config
 25:       6641          0   PCI-MSI-edge      virtio2-req.0
 26:          0          0   PCI-MSI-edge      virtio0-config
 27:        240          0   PCI-MSI-edge      virtio0-input.0
 28:          1          0   PCI-MSI-edge      virtio0-output.0
 29:          0          0   PCI-MSI-edge      virtio1-config
 30:          6          0   PCI-MSI-edge      virtio1-virtqueues
NMI:          0          0   Non-maskable interrupts
LOC:      19578       3170   Local timer interrupts
SPU:          0          0   Spurious interrupts
PMI:          0          0   Performance monitoring interrupts
IWI:        459          9   IRQ work interrupts
RTR:          0          0   APIC ICR read retries
RES:         37         81   Rescheduling interrupts
CAL:         28         16   Function call interrupts
TLB:          0          6   TLB shootdowns
TRM:          0          0   Thermal event interrupts
THR:          0          0   Threshold APIC interrupts
DFR:          0          0   Deferred Error APIC interrupts
MCE:          0          0   Machine check exceptions
MCP:          2          1   Machine check polls
ERR:          0
MIS:          0
PIN:          0          0   Posted-interrupt notification event
PIW:          0          0   Posted-interrupt wakeup event
```

内存热添加和cpu类似
```
# virsh edit CentOS-7_X86_64
<domain type='kvm'>
  <name>CentOS-7_X86_64</name>
  <uuid>f309f620-e9a1-4dd8-91e6-6a66b15d97c0</uuid>
  <memory unit='KiB'>1048576</memory>                           #最大的内存大小，最大内存大小不能超过宿主机的内存大小
  <currentMemory unit='KiB'>1048576</currentMemory>             #当前的内存大小
  <vcpu placement='auto' current='1'>2</vcpu>
  <numatune>
    <memory mode='strict' placement='auto'/>
  </numatune>
```

在宿主机上查看当前kvm虚拟机内存
```
# virsh qemu-monitor-command CentOS-7_X86_64 --hmp --cmd info balloon
balloon: actual=1024
```

在kvm虚拟机上检查
```
[root@kvm ~]# free -m
              total        used        free      shared  buff/cache   available
Mem:            992         106         762           6         124         739
Swap:             0           0           0
```

修改XML配置文件使其支持热添加
```
# virsh edit CentOS-7_X86_64
<domain type='kvm'>
  <name>CentOS-7_X86_64</name>
  <uuid>f309f620-e9a1-4dd8-91e6-6a66b15d97c0</uuid>
  <memory unit='KiB'>4194304</memory>                        #将最大的内存数改成4G
  <currentMemory unit='KiB'>1048576</currentMemory>
  <vcpu placement='auto' current='1'>2</vcpu>
  <numatune>
    <memory mode='strict' placement='auto'/>
  </numatune>
```

重启kvm虚拟机使其可以支持内存热添加。
```
# virsh shutdown CentOS-7_X86_64
域 CentOS-7_X86_64 被关闭
```

```
# virsh list --all
 Id    名称                         状态
----------------------------------------------------
 -     CentOS-7_X86_64                关闭
```

```
# virsh start CentOS-7_X86_64
域 CentOS-7_X86_64 已开始
```

```
# virsh list --all
 Id    名称                         状态
----------------------------------------------------
6     CentOS-7_X86_64                running
```

调整kvm虚拟机的内存为2G
```
# virsh qemu-monitor-command CentOS-7_X86_64 --hmp --cmd balloon 2048
```

检查
```
# free -m
              total        used        free      shared  buff/cache   available
Mem:           1742         129        1412           8         201        1379
Swap:             0           0           0
```

常用的kvm虚拟机管理工具
①.cloudstack
②.zstack
③.openstack


