title: 'postgresql在对库进行重命名操作时，报如下错误：ERROR: database "AAA" is being accessed by other
  users DETAIL: There are 3 other sessions using the databases'
date: '2020-05-18 11:29:44'
updated: '2020-05-18 12:58:31'
tags: [postgresql, 数据库]
permalink: /articles/2020/05/18/1589772584418.html
---
![](https://img.hacpai.com/bing/20180515.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

因业务需求，需要将postgresql的一个数据库重命名，执行如下重命名操作却报错
```
alter database AAA rename to AAA_bak;
```
错误如下：
```
ERROR: database "AAA" is being accessed by other users 
DETAIL: There are 3 other sessions using the databases.
```
原因：当前的数据库正在被别的用户使用，还有session在连接；
解决方法：断开当前的session连接

命令如下：
```
SELECT pg_terminate_backend(pg_stat_activity.pid) FROM pg_stat_activity WHERE datname='AAA' AND pid<>pg_backend_pid();
```
执行完毕后再执行重命名操作就正常了。
语句说明：

* pg_terminate_backend：用来终止与数据库的连接的进程id的函数。
* pg_stat_activity：是一个系统表，用于存储服务进程的属性和状态。
* pg_backend_pid()：是一个系统函数，获取附加到当前会话的服务器进程的ID。
