title: docker-ce安装
date: '2019-12-13 23:06:30'
updated: '2020-06-01 20:52:04'
tags: [docker, 容器]
permalink: /articles/2019/12/13/1576249590749.html
---
![](https://img.hacpai.com/bing/20180106.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### centos 7
### 搭建docker镜像加速器
阿里云上提供了私人的docker官方镜像地址：https://cr.console.aliyun.com
```
# mkdir -p /etc/docker
# vim /etc/docker/daemon.json
{
  "registry-mirrors": ["https://vj7cbfnu.mirror.aliyuncs.com"]
}
```
重载
```
# systemctl daemon-reload
```
# 安装docker-ce
## 安装依赖
```
# yum install -y yum-utils device-mapper-persistent-data lvm2 gcc
```
## 添加软件源信息
```
# yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```
## 安装docker-ce
```
# yum makecache fast && yum -y install docker-ce
```
## 开启docker服务
```
# systemctl start docker
# systemctl status docker
● docker.service - Docker Application Container Engine
   Loaded: loaded (/usr/lib/systemd/system/docker.service; disabled; vendor preset: disabled)
   Active: active (running) since Tue 2018-10-09 23:07:31 CST; 15h ago
     Docs: https://docs.docker.com
 Main PID: 26968 (dockerd)
   Memory: 53.7M
   CGroup: /system.slice/docker.service
           ├─26968 /usr/bin/dockerd
           └─26976 docker-containerd --config /var/run/docker/containerd/containerd.toml
Oct 09 23:07:30 ba-k8s-node-01 dockerd[26968]: time="2018-10-09T23:07:30.777809190+08:00" level=info msg="pickfirstBalancer: HandleSubConnStateChange: 0xc4203795d0, CONNECTING" module=grpc
# systemctl enable docker
Created symlink from /etc/systemd/system/multi-user.target.wants/docker.service to /usr/lib/systemd/system/docker.service.
```
注意：官方软件源默认启用了最新的软件，您可以通过编辑软件源的方式获取各个版本的软件包。例如官方并没有将测试版本的软件源置为可用，你可以通过以下方式开启。同理可以开启各种测试版本等。
```
vim /etc/yum.repos.d/docker-ce.repo
将 [docker-ce-test] 下方的 enabled=0 修改为 enabled=1
```
## 安装指定版本的docker-ce
### 查找docker-ce版本
```
# yum list docker-ce.x86_64 --showduplicates |sort -r
Loading mirror speeds from cached hostfile
Loaded plugins: fastestmirror, langpacks
Installed Packages
docker-ce.x86_64            18.06.1.ce-3.el7                   docker-ce-stable
docker-ce.x86_64            18.06.1.ce-3.el7                   @docker-ce-stable
docker-ce.x86_64            18.06.0.ce-3.el7                   docker-ce-stable
docker-ce.x86_64            18.03.1.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            18.03.0.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.12.1.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.12.0.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.09.1.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.09.0.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.06.2.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.06.1.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.06.0.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.03.3.ce-1.el7                   docker-ce-stable
docker-ce.x86_64            17.03.2.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.03.1.ce-1.el7.centos            docker-ce-stable
docker-ce.x86_64            17.03.0.ce-1.el7.centos            docker-ce-stable
Available Packages
```
### 安装指定版本的docker-ce：（version例如上面的17.03.2.ce-1.el7.centos）
`yum -y install docker-ce-[VERSION]`
```
# yum install docker-ce-17.03.2.ce-1.el7.centos -y
```
### 安装校验
```
# docker version
Client:
 Version:           18.06.1-ce
 API version:       1.38
 Go version:        go1.10.3
 Git commit:        e68fc7a
 Built:             Tue Aug 21 17:23:03 2018
 OS/Arch:           linux/amd64
 Experimental:      false

Server:
 Engine:
  Version:          18.06.1-ce
  API version:      1.38 (minimum version 1.12)
  Go version:       go1.10.3
  Git commit:       e68fc7a
  Built:            Tue Aug 21 17:25:29 2018
  OS/Arch:          linux/amd64
  Experimental:     false
```
或者
```
# docker info
Containers: 0
 Running: 0
 Paused: 0
 Stopped: 0
Images: 0
Server Version: 18.06.1-ce
Storage Driver: overlay2
 Backing Filesystem: extfs
 Supports d_type: true
 Native Overlay Diff: true
Logging Driver: json-file
Cgroup Driver: cgroupfs
Plugins:
 Volume: local
 Network: bridge host macvlan null overlay
 Log: awslogs fluentd gcplogs gelf journald json-file logentries splunk syslog
Swarm: inactive
Runtimes: runc
Default Runtime: runc
Init Binary: docker-init
containerd version: 468a545b9edcd5932818eb9de8e72413e616e86e
runc version: 69663f0bd4b60df09991c08812a60108003fa340
init version: fec3683
Security Options:
 seccomp
  Profile: default
Kernel Version: 3.10.0-693.el7.x86_64
Operating System: CentOS Linux 7 (Core)
OSType: linux
Architecture: x86_64
CPUs: 4
Total Memory: 7.639GiB
Name: ba-k8s-node-01
ID: JXHO:MS2L:BMH5:G4RS:IGUA:ZOEU:W56N:WBGV:RHJU:A7P3:COC3:KHNV
Docker Root Dir: /var/lib/docker
Debug Mode (client): false
Debug Mode (server): false
Registry: https://index.docker.io/v1/
Labels:
Experimental: false
Insecure Registries:
 127.0.0.0/8
Registry Mirrors:
 https://vj7cbfnu.mirror.aliyuncs.com/
Live Restore Enabled: false
```

#### ubuntu

# step 1: 安装必要的一些系统工具
```
sudo apt-get update
sudo apt-get -y install apt-transport-https ca-certificates curl software-properties-common
```
# step 2: 安装GPG证书
```
curl -fsSL http://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | sudo apt-key add -
```
# Step 3: 写入软件源信息
```
sudo add-apt-repository "deb [arch=amd64] http://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable"
```
# Step 4: 更新并安装 Docker-CE
```
sudo apt-get -y update
sudo apt-get -y install docker-ce
```

注意：其他注意事项在下面的注释中
# 安装指定版本的Docker-CE:
Step 1: 查找Docker-CE的版本:
```
apt-cache madison docker-ce
#   docker-ce | 17.03.1~ce-0~ubuntu-xenial | http://mirrors.aliyun.com/docker-ce/linux/ubuntu xenial/stable amd64 Packages
#   docker-ce | 17.03.0~ce-0~ubuntu-xenial | http://mirrors.aliyun.com/docker-ce/linux/ubuntu xenial/stable amd64 Packages
```
Step 2: 安装指定版本的Docker-CE: (VERSION 例如上面的 17.03.1~ce-0~ubuntu-xenial)
```
sudo apt-get -y install docker-ce=[VERSION]
```

