title: 分布式存储之FastDFS搭建部署(基于ubuntu系统)
date: '2019-12-12 23:12:17'
updated: '2019-12-17 14:41:14'
tags: [分布式存储, fastdfs, ubuntu, nginx]
permalink: /articles/2019/12/12/1576163536907.html
---
![](https://img.hacpai.com/bing/20190716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 资源准备

| 主机名| IP| 规格|系统盘|数据盘|用途|备注|
| xtzx01 | 172.25.38.5 | 40核125G |600G(raid 1)|7.3T*9(raid 0)|tracker+storage+nginx|group1|
| xtzx02 | 172.25.38.6 |40核125G |600G(raid 1)|7.3T*9(raid 0)|storage+nginx|group1|
|  xtzx03| 172.25.38.7 | 40核125G |600G(raid 1)|7.3T*9(raid 0)|storage+nginx|group1|
|xtzx04|172.25.38.8|40核125G|600G(raid 1)|7.3T*9(raid 0)|tracker+storage+nginx|group2|
|xtzx05|172.25.38.9|40核125G|600G(raid 1)|7.3T*9(raid 0)|storage+nginx|group2|
|xtzx06|172.25.38.10|40核125G|600G(raid 1)|7.3T*9(raid 0)|storage+nginx|group2|
| --- | --- | --- |
注意：
A.  所有机器的系统均为ubuntu 18.04.3;

B.  系统盘是两块600G的数据盘做的raid 1；

C.  数据盘是8块8T的磁盘，单盘做raid 0；

# 系统优化
## 更换国内yum源
```
# cp /etc/apt/sources.list{,.bak}     ###先备份
# cat >/etc/apt/sources.list <<EOF
deb http://mirrors.aliyun.com/ubuntu/ bionic main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ bionic-security main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-security main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ bionic-updates main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-updates main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ bionic-proposed main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-proposed main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ bionic-backports main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-backports main restricted universe multiverse
EOF
```
## 修改时区
```
# cat /etc/localtime 
TZif2UTCTZif2?UTC
UTC0
# tzselect
Please identify a location so that time zone rules can be set correctly.
Please select a continent, ocean, "coord", or "TZ".、
 1) Africa
 2) Americas
 3) Antarctica
 4) Asia
 5) Atlantic Ocean
 6) Australia
 7) Europe
 8) Indian Ocean
 9) Pacific Ocean
10) coord - I want to use geographical coordinates.
11) TZ - I want to specify the time zone using the Posix TZ format.
#? 4
Please select a country whose clocks agree with yours.
 1) Afghanistan        18) Israel          35) Palestine
 2) Armenia         19) Japan           36) Philippines
 3) Azerbaijan         20) Jordan          37) Qatar
 4) Bahrain         21) Kazakhstan      38) Russia
 5) Bangladesh         22) Korea (North)      39) Saudi Arabia
 6) Bhutan      23) Korea (South)      40) Singapore
 7) Brunei      24) Kuwait          41) Sri Lanka
 8) Cambodia        25) Kyrgyzstan      42) Syria
 9) China       26) Laos        43) Taiwan
10) Cyprus     27) Lebanon         44) Tajikistan
11) East Timor         28) Macau           45) Thailand
12) Georgia         29) Malaysia           46) Turkmenistan
13) Hong Kong       30) Mongolia           47) United Arab Emirates
14) India      31) Myanmar (Burma)        48) Uzbekistan
15) Indonesia       32) Nepal           49) Vietnam
16) Iran       33) Oman        50) Yemen
17) Iraq       34) Pakistan
#?9
Please select one of the following time zone regions.
1) Beijing Time
2) Xinjiang Time
#? 1
The following information has been given:
    China
    Beijing Time
Therefore TZ='Asia/Shanghai' will be used.
Selected time is now:    Fri Nov 29 09:52:47 CST 2019.
Universal Time is now:   Fri Nov 29 01:52:47 UTC 2019.
Is the above information OK?
1) Yes
2) No
#? 1
You can make this change permanent for yourself by appending the line
    TZ='Asia/Shanghai'; export TZ
to the file '.profile' in your home directory; then log out and log in again.
Here is that TZ value again, this time on standard output so that you
can use the /usr/bin/tzselect command in shell scripts:
Asia/Shanghai
# cp /usr/share/zoneinfo/Asia/Shanghai  /etc/localtime
# date
Fri Nov 29 09:53:36 CST 2019
```
## 更新源
```
# apt-get update
```
## 关闭selinux和firewalld
```
# systemctl stop firewalld 
# systemctl disable firewalld 
# setenforce 0 
# sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/sysconfig/selinux
```
此步操作针对centos系统。
## 修改DNS
```
# echo "nameserver 223.5.5.5" >>/etc/resolv.conf
```
## 安装依赖
```
# apt-get install vim wget git libpcre3 libpcre3-dev build-essential zlib1g-dev openssl libssl-dev -y
```
# FastDFS安装
## 安装FastDFS依赖库
### 下载FastDFS依赖库
```
# cd /usr/local/src/
# git clone https://github.com/happyfish100/libfastcommon.git
# ls -l
total 384
drwxr-xr-x  3 root root  4096 Dec  3 10:40 ./
drwxr-xr-x 10 root root   4096 Aug  6 03:22 ../
drwxr-xr-x  6 root root  4096 Dec  3 10:39 libfastcommon/
```
### 编译FastDFS依赖库
```
# cd libfastcommon
# ./make.sh
```
### 编译安装FastDFS依赖库
```
# ./make.sh install
```
## 安装FastDFS
### 下载FastDFS二进制安装包（基于5.12版本安装）
```
# cd /usr/local/src
# wget https://github.com/happyfish100/fastdfs/archive/V5.12.tar.gz
# ls -l
total 384
drwxr-xr-x  3 root root  4096 Dec  3 10:40 ./
drwxr-xr-x 10 root root   4096 Aug  6 03:22 ../
drwxr-xr-x  6 root root  4096 Dec  3 10:39 libfastcommon/
-rw-r--r--  1 root root 378615 Dec  3 10:40 V5.12.tar.gz
```
### 解压FastDFS二进制安装包
```
# tar zcvf V5.12.tar.gz
# ll
total 388
drwxr-xr-x  4 root root  4096 Dec  3 10:45 ./
drwxr-xr-x 10 root root   4096 Aug  6 03:22 ../
drwxrwxr-x 11 root root   4096 Sep 12 10:25 fastdfs-5.12/
drwxr-xr-x  6 root root  4096 Dec  3 10:39 libfastcommon/
-rw-r--r--  1 root root 378615 Dec  3 10:40 V5.12.tar.gz
```
### 编译FastDFS
```
# cd fastdfs-5.12
# ./make.sh
```
### 编译安装FastDFS
```
# ./make.sh install
```
### 配置
```
# cd /etc/fdfs
# cp client.conf.sample client.conf
# cp storage.conf.sample storage.conf
# cp storage_ids.conf.sample storage_ids.conf
# cp tracker.conf.sample tracker.conf
```
#### 修改tracker配置文件
```
# grep -Ev "^#|^$" /etc/fdfs/tracker.conf
disabled=false
bind_addr=172.25.38.5            ####监听本机内网IP
port=22122
connect_timeout=30
network_timeout=60
base_path=/data/fastdfs/tracker         ####tracker的运行日志及元数据存放目录，需提前创建好
max_connections=1024
accept_threads=1
work_threads=4
min_buff_size = 8KB
max_buff_size = 128KB
store_lookup=2
store_group=group2
store_server=0
store_path=0
download_server=0
reserved_storage_space = 10%
log_level=info
run_by_group=
run_by_user=
allow_hosts=*
sync_log_buff_interval = 10
check_active_interval = 120
thread_stack_size = 256KB
storage_ip_changed_auto_adjust = true
storage_sync_file_max_delay = 86400
storage_sync_file_max_time = 300
use_trunk_file = false 
slot_min_size = 256
slot_max_size = 16MB
trunk_file_size = 64MB
trunk_create_file_advance = false
trunk_create_file_time_base = 02:00
trunk_create_file_interval = 86400
trunk_create_file_space_threshold = 20G
trunk_init_check_occupying = false
trunk_init_reload_from_binlog = false
trunk_compress_binlog_min_interval = 0
use_storage_id = false
storage_ids_filename = storage_ids.conf
id_type_in_filename = ip
store_slave_file_use_link = false
rotate_error_log = false
error_log_rotate_time=00:00
rotate_error_log_size = 0
log_file_keep_days = 0
use_connection_pool = false
connection_pool_max_idle_time = 3600
http.server_port=8080
http.check_alive_interval=30
http.check_alive_type=tcp
http.check_alive_uri=/status.html
```
#### 修改storage配置文件
```
# grep -Ev "^$|^#" /etc/fdfs/storage.conf
disabled=false
group_name=group1              ###根据你对storage的划分，来填写
bind_addr=172.25.38.5            ###监听本机的内网IP
client_bind=true
port=9096                         ###监听的端口，可以自行修改，默认23000
connect_timeout=10
network_timeout=60
heart_beat_interval=30
stat_report_interval=60
base_path=/data/fastdfs/storage      ###storage的运行日志，需提前创建好
max_connections=1024
buff_size = 256KB
accept_threads=1
work_threads=4
disk_rw_separated = true
disk_reader_threads = 1
disk_writer_threads = 1
sync_wait_msec=50
sync_interval=0
sync_start_time=00:00
sync_end_time=23:59
write_mark_file_freq=500
store_path_count=9
store_path0=/data_sdb1/storage         ###存储路径，单块盘添加一个即可
store_path1=/data_sdc1/storage
store_path2=/data_sdd1/storage
store_path3=/data_sde1/storage
store_path4=/data_sdf1/storage
store_path5=/data_sdg1/storage
store_path6=/data_sdh1/storage
store_path7=/data_sdi1/storage
store_path8=/data_sdj1/storage
subdir_count_per_path=256
tracker_server=172.25.38.5:22122       ###tracker的地址，有几个添加几个
tracker_server=172.25.38.8:22122
log_level=info
run_by_group=
run_by_user=
allow_hosts=*
file_distribute_path_mode=0
file_distribute_rotate_count=100
fsync_after_written_bytes=0
sync_log_buff_interval=10
sync_binlog_buff_interval=10
sync_stat_file_interval=300
thread_stack_size=512KB
upload_priority=10
if_alias_prefix=
check_file_duplicate=0
file_signature_method=hash
key_namespace=FastDFS
keep_alive=0
use_access_log = false
rotate_access_log = false
access_log_rotate_time=00:00
rotate_error_log = false
error_log_rotate_time=00:00
rotate_access_log_size = 0
rotate_error_log_size = 0
log_file_keep_days = 0
file_sync_skip_invalid_record=false
use_connection_pool = false
connection_pool_max_idle_time = 3600
http.domain_name=
http.server_port=80
```
#### 修改client的配置文件
```
# grep -Ev "^#|^$" client.conf
connect_timeout=10
network_timeout=60
base_path=/data/fastdfs/client   ###clinet的日志目录，需提前创建好
tracker_server=172.25.38.5:22122  ###tracker的地址，有几个添加几个
tracker_server=172.25.38.8:22122
log_level=info
use_connection_pool = false
connection_pool_max_idle_time = 3600
load_fdfs_parameters_from_tracker=false
use_storage_id = false
storage_ids_filename = storage_ids.conf
http.tracker_server_port=8080        ###和tracker_http_server保持一致
```
## 安装nginx
注意：所有的storage机器上都需要安装nginx。
###  创建一个nginx普通用户
```
# useradd -s /sbin/nologin -M nginx
```
### 下载nginx
```
# cd /usr/local/src
# wget http://nginx.org/download/nginx-1.16.1.tar.gz
```
### 下载FastDFS所需的nginx模块
```
# cd /usr/local/src
# wget https://github.com/happyfish100/fastdfs-nginx-module/archive/V1.20.tar.gz
# ls -l
total 1420
drwxr-xr-x  4 root root   4096 Dec  3 13:42 ./
drwxr-xr-x 10 root root    4096 Aug  6 03:22 ../
drwxrwxr-x 11 root root    4096 Sep 12 10:25 fastdfs-5.12/
drwxr-xr-x  6 root root   4096 Dec  3 10:39 libfastcommon/
-rw-r--r--  1 root root 1032630 Aug 14 01:01 nginx-1.16.1.tar.gz
-rw-r--r--  1 root root  19825 Dec  3 13:42 V1.20.tar.gz
-rw-r--r--  1 root root 378615 Dec  3 10:40 V5.12.tar.gz
```
### 解压nginx二进制包和FastDFS模块
```
# tar xvf V1.20.tar.gz
# tar xvf nginx-1.16.1.tar.gz
# ll
total 1428
drwxr-xr-x  6 root root   4096 Dec  3 13:50 ./
drwxr-xr-x 10 root root    4096 Aug  6 03:22 ../
drwxrwxr-x 11 root root    4096 Sep 12 10:25 fastdfs-5.12/
drwxrwxr-x  3 root root   4096 Jul  5  2018 fastdfs-nginx-module-1.20/
drwxr-xr-x  6 root root   4096 Dec  3 10:39 libfastcommon/
drwxr-xr-x  8 1001 1001   4096 Aug 13 20:51nginx-1.16.1/
-rw-r--r--  1 root root 1032630 Aug 14 01:01 nginx-1.16.1.tar.gz
-rw-r--r--  1 root root  19825 Dec  3 13:42 V1.20.tar.gz
-rw-r--r--  1 root root 378615 Dec  3 10:40 V5.12.tar.gz
```
### 初始化nginx
```
# cd nginx-1.16.1/
# ./configure --prefix=/usr/local/nginx --user=nginx --group=nginx --with-http_ssl_module --with-http_stub_status_module --add-module=/usr/local/src/fastdfs-nginx-module-1.20/src
```
### 编译nginx
```
# make
```
### 编译安装nginx
```
# make install
```
### 配置
```
# cp /usr/local/src/fastdfs-nginx-module-1.20/src/mod_fastdfs.conf /etc/fdfs/
# cp /usr/local/src/fastdfs-5.12/conf/anti-steal.jpg /etc/fdfs/
# cp /usr/local/src/fastdfs-5.12/conf/http.conf /etc/fdfs/
# cp /usr/local/src/fastdfs-5.12/conf/mime.types /etc/fdfs/
```
### 修改nginx配置文件
```
# vim /usr/local/nginx/conf/nginx.conf

user nginx nginx;

worker_processes auto;

error_log  /usr/local/nginx/logs/nginx-error.log  crit;

pid        /usr/local/nginx/logs/nginx.pid;

worker_rlimit_nofile 1048576;

events
    {
        use epoll;
        worker_connections 131072;
        multi_accept on;
    }

http
    {
        include       mime.types;
        default_type  application/octet-stream;
        server_names_hash_bucket_size 128;
        client_header_buffer_size 32k;
        large_client_header_buffers 4 32k;
        client_max_body_size 50m;
        proxy_ignore_client_abort on;
        fastcgi_ignore_client_abort on;

        sendfile   on;
        tcp_nopush on;
        keepalive_timeout 60;
        tcp_nodelay on;

        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
        fastcgi_buffer_size 64k;
        fastcgi_buffers 4 64k;
        fastcgi_busy_buffers_size 128k;
        fastcgi_temp_file_write_size 256k;

        gzip on;
        gzip_min_length  1k;
        gzip_buffers     4 16k;
        gzip_http_version 1.1;
        gzip_comp_level 2;
        gzip_types     text/plain application/javascript application/x-javascript text/javascript text/css application/xml application/xml+rss;
        gzip_vary on;
        gzip_proxied   expired no-cache no-store private auth;
        gzip_disable   "MSIE [1-6]\.";
        server_tokens off;

        log_format  access     '$status|$request_time|$http_x_forwarded_for|$time_local|$host|$request|'
                          '$body_bytes_sent|$http_referer|$upstream_response_time|'
                          '$upstream_addr|$upstream_connect_time|$http_user_agent';
    access_log off;

server
    {
        listen 80 default_server;
        server_name localhost;
        index index.html index.htm index.php;
        root /usr/local/nginx

    location ~ /group[0-9]/ {
            ngx_fastdfs_module;
        }
    }
        access_log  /usr/local/nginx/logs/nginx-access.log  access;
include vhost/*.conf;
}

```
### 修改mod_fastdfs配置文件
```
# grep -Ev "^#|^$" /etc/fdfs/mod_fastdfs.conf
connect_timeout=2
network_timeout=30
base_path=/data/fastdfs/mod_fastdfs        ###这个需提前创建
load_fdfs_parameters_from_tracker=true
storage_sync_file_max_delay = 86400
use_storage_id = false
storage_ids_filename = storage_ids.conf
tracker_server=172.25.38.5:22122
tracker_server=172.25.38.8:22122
storage_server_port=9096
group_name=group1                           ###根据当前的storage分组设置
url_have_group_name = true
store_path_count=9                            ###根据你的store_path数量来设置
store_path0=/data_sdb1/storage
store_path1=/data_sdc1/storage
store_path2=/data_sdd1/storage
store_path3=/data_sde1/storage
store_path4=/data_sdf1/storage
store_path5=/data_sdg1/storage
store_path6=/data_sdh1/storage
store_path7=/data_sdi1/storage
store_path8=/data_sdj1/storage
log_level=info
log_filename=
response_mode=proxy
if_alias_prefix=
flv_support = true
flv_extension = flv
group_count = 2
[group1]
group_name=group1
storage_server_port=9096
store_path_count=9
store_path0=/data_sdb1/storage
store_path1=/data_sdc1/storage
store_path2=/data_sdd1/storage
store_path3=/data_sde1/storage
store_path4=/data_sdf1/storage
store_path5=/data_sdg1/storage
store_path6=/data_sdh1/storage
store_path7=/data_sdi1/storage
store_path8=/data_sdj1/storage
[group2]
group_name=group2
storage_server_port=9096
store_path_count=9
store_path0=/data_sdb1/storage
store_path1=/data_sdc1/storage
store_path2=/data_sdd1/storage
store_path3=/data_sde1/storage
store_path4=/data_sdf1/storage
store_path5=/data_sdg1/storage
store_path6=/data_sdh1/storage
store_path7=/data_sdi1/storage
store_path8=/data_sdj1/storage
```
### 启动服务
#### 启动tracker服务
```
# /usr/bin/fdfs_trackerd /etc/fdfs/tracker.conf
```
注意：如果启动报错，请检查/data/fastdfs/tracker/logs/trackerd.log。

#### 启动storage服务
```
# /usr/bin/fdfs_storaged /etc/fdfs/storage.conf
```
注意：如果启动报错，请检查/data/fastdfs/storage/logs/storaged.log。
#### 启动nginx服务
```
# /usr/local/nginx/sbin/nginx -t           ###检查语法
ngx_http_fastdfs_set pid=20764
nginx: the configuration file /usr/local/nginx/conf/nginx.conf syntax is ok
nginx: configuration file /usr/local/nginx/conf/nginx.conf test is successful
# /usr/local/nginx/sbin/nginx -V         ###查看nginx编译模块
nginx version: nginx/1.16.1
built by gcc 7.4.0 (Ubuntu 7.4.0-1ubuntu1~18.04.1) 
built with OpenSSL 1.1.1  11 Sep 2018
TLS SNI support enabled
configure arguments: --prefix=/usr/local/nginx --user=nginx --group=nginx --with-http_ssl_module --with-http_stub_status_module --add-module=/usr/local/src/fastdfs-nginx-module-1.20/src
# /usr/local/nginx/sbin/nginx              ###启动nginx服务
ngx_http_fastdfs_set pid=20769
```
### 检查服务
```
# /usr/bin/fdfs_monitor /etc/fdfs/client.conf
[2019-12-13 00:00:47] DEBUG - base_path=/data/fastdfs/client, connect_timeout=10, network_timeout=60, tracker_server_count=2, anti_steal_token=0, anti_steal_secret_key length=0, use_connection_pool=0, g_connection_pool_max_idle_time=3600s, use_storage_id=0, storage server id count: 0

server_count=2, server_index=1

tracker server is 172.25.38.8:22122

group count: 2

Group 1:
group name = group1
disk total space = 61592259 MB
disk free space = 61491581 MB
trunk free space = 0 MB
storage server count = 3
active server count = 3
storage server port = 9096
storage HTTP port = 80
store path count = 9
subdir count per path = 256
current write server index = 0
current trunk file id = 0

	Storage 1:
		id = 172.25.38.5
		ip_addr = 172.25.38.5 (anantes-651-1-49-net.w2-0.abo.wanadoo.fr)  ACTIVE
		http domain = 
		version = 5.12
		join time = 2019-12-03 11:24:18
		up time = 2019-12-11 11:36:04
		total storage = 68659290 MB
		free storage = 68590181 MB
		upload priority = 10
		store_path_count = 9
		subdir_count_per_path = 256
		storage_port = 9096
		storage_http_port = 80
		current_write_path = 0
		source storage id = 
		if_trunk_server = 0
		connection.alloc_count = 256
		connection.current_count = 2
		connection.max_count = 2
		total_upload_count = 0
		success_upload_count = 0
		total_append_count = 0
		success_append_count = 0
		total_modify_count = 0
		success_modify_count = 0
		total_truncate_count = 0
		success_truncate_count = 0
		total_set_meta_count = 0
		success_set_meta_count = 0
		total_delete_count = 0
		success_delete_count = 0
		total_download_count = 0
		success_download_count = 0
		total_get_meta_count = 0
		success_get_meta_count = 0
		total_create_link_count = 0
		success_create_link_count = 0
		total_delete_link_count = 0
		success_delete_link_count = 0
		total_upload_bytes = 0
		success_upload_bytes = 0
		total_append_bytes = 0
		success_append_bytes = 0
		total_modify_bytes = 0
		success_modify_bytes = 0
		stotal_download_bytes = 0
		success_download_bytes = 0
		total_sync_in_bytes = 0
		success_sync_in_bytes = 0
		total_sync_out_bytes = 0
		success_sync_out_bytes = 0
		total_file_open_count = 0
		success_file_open_count = 0
		total_file_read_count = 0
		success_file_read_count = 0
		total_file_write_count = 0
		success_file_write_count = 0
		last_heart_beat_time = 2019-12-13 00:01:02
		last_source_update = 1970-01-01 08:00:00
		last_sync_update = 1970-01-01 08:00:00
		last_synced_timestamp = 1970-01-01 08:00:00 
	Storage 2:
		id = 172.25.38.6
		ip_addr = 172.25.38.6 (anantes-651-1-49-net.w2-0.abo.wanadoo.fr)  ACTIVE
		http domain = 
		version = 5.12
		join time = 2019-12-03 16:54:19
		up time = 2019-12-11 11:36:48
		total storage = 61592259 MB
		free storage = 61491581 MB
		upload priority = 10
		store_path_count = 9
		subdir_count_per_path = 256
		storage_port = 9096
		storage_http_port = 80
		current_write_path = 0
		source storage id = 172.25.38.5
		if_trunk_server = 0
		connection.alloc_count = 256
		connection.current_count = 2
		connection.max_count = 2
		total_upload_count = 0
		success_upload_count = 0
		total_append_count = 0
		success_append_count = 0
		total_modify_count = 0
		success_modify_count = 0
		total_truncate_count = 0
		success_truncate_count = 0
		total_set_meta_count = 0
		success_set_meta_count = 0
		total_delete_count = 0
		success_delete_count = 0
		total_download_count = 0
		success_download_count = 0
		total_get_meta_count = 0
		success_get_meta_count = 0
		total_create_link_count = 0
		success_create_link_count = 0
		total_delete_link_count = 0
		success_delete_link_count = 0
		total_upload_bytes = 0
		success_upload_bytes = 0
		total_append_bytes = 0
		success_append_bytes = 0
		total_modify_bytes = 0
		success_modify_bytes = 0
		stotal_download_bytes = 0
		success_download_bytes = 0
		total_sync_in_bytes = 0
		success_sync_in_bytes = 0
		total_sync_out_bytes = 0
		success_sync_out_bytes = 0
		total_file_open_count = 0
		success_file_open_count = 0
		total_file_read_count = 0
		success_file_read_count = 0
		total_file_write_count = 0
		success_file_write_count = 0
		last_heart_beat_time = 2019-12-13 00:01:10
		last_source_update = 1970-01-01 08:00:00
		last_sync_update = 1970-01-01 08:00:00
		last_synced_timestamp = 1970-01-01 08:00:00 
	Storage 3:
		id = 172.25.38.7
		ip_addr = 172.25.38.7 (anantes-651-1-49-net.w2-0.abo.wanadoo.fr)  ACTIVE
		http domain = 
		version = 5.12
		join time = 2019-12-03 15:55:04
		up time = 2019-12-11 11:36:47
		total storage = 61592259 MB
		free storage = 61491581 MB
		upload priority = 10
		store_path_count = 9
		subdir_count_per_path = 256
		storage_port = 9096
		storage_http_port = 80
		current_write_path = 0
		source storage id = 172.25.38.5
		if_trunk_server = 0
		connection.alloc_count = 256
		connection.current_count = 2
		connection.max_count = 2
		total_upload_count = 0
		success_upload_count = 0
		total_append_count = 0
		success_append_count = 0
		total_modify_count = 0
		success_modify_count = 0
		total_truncate_count = 0
		success_truncate_count = 0
		total_set_meta_count = 0
		success_set_meta_count = 0
		total_delete_count = 0
		success_delete_count = 0
		total_download_count = 0
		success_download_count = 0
		total_get_meta_count = 0
		success_get_meta_count = 0
		total_create_link_count = 0
		success_create_link_count = 0
		total_delete_link_count = 0
		success_delete_link_count = 0
		total_upload_bytes = 0
		success_upload_bytes = 0
		total_append_bytes = 0
		success_append_bytes = 0
		total_modify_bytes = 0
		success_modify_bytes = 0
		stotal_download_bytes = 0
		success_download_bytes = 0
		total_sync_in_bytes = 0
		success_sync_in_bytes = 0
		total_sync_out_bytes = 0
		success_sync_out_bytes = 0
		total_file_open_count = 0
		success_file_open_count = 0
		total_file_read_count = 0
		success_file_read_count = 0
		total_file_write_count = 0
		success_file_write_count = 0
		last_heart_beat_time = 2019-12-13 00:00:45
		last_source_update = 1970-01-01 08:00:00
		last_sync_update = 1970-01-01 08:00:00
		last_synced_timestamp = 1970-01-01 08:00:00 

Group 2:
group name = group2
disk total space = 68659290 MB
disk free space = 68590033 MB
trunk free space = 0 MB
storage server count = 3
active server count = 3
storage server port = 9096
storage HTTP port = 80
store path count = 9
subdir count per path = 256
current write server index = 0
current trunk file id = 0

	Storage 1:
		id = 172.25.38.10
		ip_addr = 172.25.38.10 (anantes-651-1-49-net.w2-0.abo.wanadoo.fr)  ACTIVE
		http domain = 
		version = 5.12
		join time = 2019-12-03 18:25:22
		up time = 2019-12-11 11:38:02
		total storage = 68659290 MB
		free storage = 68590033 MB
		upload priority = 10
		store_path_count = 9
		subdir_count_per_path = 256
		storage_port = 9096
		storage_http_port = 80
		current_write_path = 0
		source storage id = 172.25.38.8
		if_trunk_server = 0
		connection.alloc_count = 256
		connection.current_count = 2
		connection.max_count = 4
		total_upload_count = 4
		success_upload_count = 4
		total_append_count = 0
		success_append_count = 0
		total_modify_count = 0
		success_modify_count = 0
		total_truncate_count = 0
		success_truncate_count = 0
		total_set_meta_count = 4
		success_set_meta_count = 4
		total_delete_count = 0
		success_delete_count = 0
		total_download_count = 0
		success_download_count = 0
		total_get_meta_count = 0
		success_get_meta_count = 0
		total_create_link_count = 0
		success_create_link_count = 0
		total_delete_link_count = 0
		success_delete_link_count = 0
		total_upload_bytes = 5479904
		success_upload_bytes = 5479904
		total_append_bytes = 0
		success_append_bytes = 0
		total_modify_bytes = 0
		success_modify_bytes = 0
		stotal_download_bytes = 0
		success_download_bytes = 0
		total_sync_in_bytes = 146699476
		success_sync_in_bytes = 146699476
		total_sync_out_bytes = 0
		success_sync_out_bytes = 0
		total_file_open_count = 12
		success_file_open_count = 12
		total_file_read_count = 0
		success_file_read_count = 0
		total_file_write_count = 588
		success_file_write_count = 588
		last_heart_beat_time = 2019-12-13 00:00:52
		last_source_update = 2019-12-11 13:23:21
		last_sync_update = 2019-12-11 13:25:08
		last_synced_timestamp = 2019-12-11 13:23:47 (0s delay)
	Storage 2:
		id = 172.25.38.8
		ip_addr = 172.25.38.8 (anantes-651-1-49-net.w2-0.abo.wanadoo.fr)  ACTIVE
		http domain = 
		version = 5.12
		join time = 2019-12-03 17:00:00
		up time = 2019-12-11 11:36:44
		total storage = 68659290 MB
		free storage = 68590033 MB
		upload priority = 10
		store_path_count = 9
		subdir_count_per_path = 256
		storage_port = 9096
		storage_http_port = 80
		current_write_path = 0
		source storage id = 
		if_trunk_server = 0
		connection.alloc_count = 256
		connection.current_count = 2
		connection.max_count = 4
		total_upload_count = 4
		success_upload_count = 4
		total_append_count = 0
		success_append_count = 0
		total_modify_count = 0
		success_modify_count = 0
		total_truncate_count = 0
		success_truncate_count = 0
		total_set_meta_count = 4
		success_set_meta_count = 4
		total_delete_count = 0
		success_delete_count = 0
		total_download_count = 0
		success_download_count = 0
		total_get_meta_count = 0
		success_get_meta_count = 0
		total_create_link_count = 0
		success_create_link_count = 0
		total_delete_link_count = 0
		success_delete_link_count = 0
		total_upload_bytes = 146699280
		success_upload_bytes = 146699280
		total_append_bytes = 0
		success_append_bytes = 0
		total_modify_bytes = 0
		success_modify_bytes = 0
		stotal_download_bytes = 0
		success_download_bytes = 0
		total_sync_in_bytes = 5480100
		success_sync_in_bytes = 5480100
		total_sync_out_bytes = 0
		success_sync_out_bytes = 0
		total_file_open_count = 12
		success_file_open_count = 12
		total_file_read_count = 0
		success_file_read_count = 0
		total_file_write_count = 588
		success_file_write_count = 588
		last_heart_beat_time = 2019-12-13 00:00:45
		last_source_update = 2019-12-11 13:23:47
		last_sync_update = 2019-12-11 13:22:08
		last_synced_timestamp = 2019-12-11 13:23:21 (0s delay)
	Storage 3:
		id = 172.25.38.9
		ip_addr = 172.25.38.9 (anantes-651-1-49-net.w2-0.abo.wanadoo.fr)  ACTIVE
		http domain = 
		version = 5.12
		join time = 2019-12-03 17:32:01
		up time = 2019-12-11 11:37:34
		total storage = 68659290 MB
		free storage = 68590033 MB
		upload priority = 10
		store_path_count = 9
		subdir_count_per_path = 256
		storage_port = 9096
		storage_http_port = 80
		current_write_path = 0
		source storage id = 172.25.38.8
		if_trunk_server = 0
		connection.alloc_count = 256
		connection.current_count = 2
		connection.max_count = 3
		total_upload_count = 0
		success_upload_count = 0
		total_append_count = 0
		success_append_count = 0
		total_modify_count = 0
		success_modify_count = 0
		total_truncate_count = 0
		success_truncate_count = 0
		total_set_meta_count = 0
		success_set_meta_count = 0
		total_delete_count = 0
		success_delete_count = 0
		total_download_count = 0
		success_download_count = 0
		total_get_meta_count = 0
		success_get_meta_count = 0
		total_create_link_count = 0
		success_create_link_count = 0
		total_delete_link_count = 0
		success_delete_link_count = 0
		total_upload_bytes = 0
		success_upload_bytes = 0
		total_append_bytes = 0
		success_append_bytes = 0
		total_modify_bytes = 0
		success_modify_bytes = 0
		stotal_download_bytes = 0
		success_download_bytes = 0
		total_sync_in_bytes = 152179576
		success_sync_in_bytes = 152179576
		total_sync_out_bytes = 0
		success_sync_out_bytes = 0
		total_file_open_count = 16
		success_file_open_count = 16
		total_file_read_count = 0
		success_file_read_count = 0
		total_file_write_count = 592
		success_file_write_count = 592
		last_heart_beat_time = 2019-12-13 00:00:47
		last_source_update = 1970-01-01 08:00:00
		last_sync_update = 2019-12-11 13:24:43
		last_synced_timestamp = 2019-12-11 13:23:21 (26s delay)
```
注意：执行完毕，会在输出中看到ACTIVE。
```
# netstat -lntp
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address          Foreign Address         State       PID/Program name    
tcp        0     0 0.0.0.0:80              0.0.0.0:*               LISTEN      20770/nginx: master 
tcp        0     0 127.0.0.53:53          0.0.0.0:*               LISTEN      11289/systemd-resol 
tcp        0     0 0.0.0.0:22             0.0.0.0:*               LISTEN      2739/sshd           
tcp        0     0 172.25.38.5:9096        0.0.0.0:*               LISTEN      13489/fdfs_storaged 
tcp        0     0 172.25.38.5:22122       0.0.0.0:*               LISTEN      13210/fdfs_trackerd 
tcp6       0     0 :::52113               :::*                    LISTEN      37731/(squid-1)     
tcp6       0     0 :::22                  :::*                    LISTEN      2739/sshd
```
注意：其中，80端口是nginx启动监听的端口，22122是tracker启动监听的端口，9096是storage启动监听的端口。
通过检查启动日志
```
# less /data/fastdfs/tracker/logs/trackerd.log
# less /data/fastdfs/storage/logs/storaged.log
# less /usr/local/nginx/logs/nginx-error.log
```
注意：storage启动成功后，存储目录下会生成很多层级目录：
```
# tree -L 2 /data_sd*/
/data_sdb1/

└── storage

└── data

/data_sdc1/

└── storage

└── data

/data_sdd1/

└── storage

└── data

/data_sde1/

└── storage

└── data

/data_sdf1/

└── storage

└── data

/data_sdg1/

└── storage

└── data

/data_sdh1/

└── storage

└── data

/data_sdi1/

└── storage

└── data

/data_sdj1/

└── storage

└── data

  

18 directories, 0 files
```
同理的方法在其他的几台机器上都部署上相关服务服务（见资源准备中的机器用途）。
### FastDFS上传文件测试
```
# fdfs_test /etc/fdfs/client.conf upload FastDFS测试视频01.mp4
This is FastDFS client test program v5.12
 Copyright (C) 2008, Happy Fish / YuQing
FastDFS may be copied only under the terms of the GNU General
Public License V3, which may be found in the FastDFS source kit.
Please visit the FastDFS Home Page http://www.csource.org/ 
for more detail.

 [2019-12-04 10:02:42] DEBUG - base_path=/data/fastdfs/client, connect_timeout=10, network_timeout=60, tracker_server_count=2, anti_steal_token=0, anti_steal_secret_key length=0, use_connection_pool=0, g_connection_pool_max_idle_time=3600s, use_storage_id=0, storage server id count: 0

 tracker_query_storage_store_list_without_group:

    server 1. group_name=, ip_addr=172.25.38.5, port=9096
    server 2. group_name=, ip_addr=172.25.38.6, port=9096
    server 3. group_name=, ip_addr=172.25.38.7, port=9096

group_name=group1, ip_addr=172.25.38.5, port=9096
storage_upload_by_filename
group_name=group1, remote_filename=M01/00/00/rBkmBV3nE8KAYCyKAi-dBKpKcKg471.mp4
source ip address: 172.25.38.5
file timestamp=2019-12-04 10:02:42
file size=36674820
file crc32=2857005224
example file url: http://172.25.38.5:8080/group1/M01/00/00/rBkmBV3nE8KAYCyKAi-dBKpKcKg471.mp4
storage_upload_slave_by_filename
group_name=group1, remote_filename=M01/00/00/rBkmBV3nE8KAYCyKAi-dBKpKcKg471_big.mp4
source ip address: 172.25.38.5
file timestamp=2019-12-04 10:02:43
file size=36674820
file crc32=2857005224
example file url: 
http://172.25.38.5:8080/group1/M01/00/00/rBkmBV3nE8KAYCyKAi-dBKpKcKg471_big.mp4
# fdfs_test /etc/fdfs/client.conf upload FastDFS测试视频02.mp4
This is FastDFS client test program v5.12
Copyright (C) 2008, Happy Fish / YuQing

FastDFS may be copied only under the terms of the GNU General
Public License V3, which may be found in the FastDFS source kit.
Please visit the FastDFS Home Page http://www.csource.org/ 
for more detail.

 

[2019-12-04 10:05:20] DEBUG - base_path=/data/fastdfs/client, connect_timeout=10, network_timeout=60, tracker_server_count=2, anti_steal_token=0, anti_steal_secret_key length=0, use_connection_pool=0, g_connection_pool_max_idle_time=3600s, use_storage_id=0, storage server id count: 0

tracker_query_storage_store_list_without_group:

    server 1. group_name=, ip_addr=172.25.38.10, port=9096
    server 2. group_name=, ip_addr=172.25.38.8, port=9096
    server 3. group_name=, ip_addr=172.25.38.9, port=9096

group_name=group2, ip_addr=172.25.38.10, port=9096
storage_upload_by_filename
group_name=group2, remote_filename=M01/00/00/rBkmCl3nFMGAT5ZnABTneGRQopk834.mp4
source ip address: 172.25.38.10
file timestamp=2019-12-04 10:06:57
file size=1369976
file crc32=1683006105
example file url: http://172.25.38.10:8080/group2/M01/00/00/rBkmCl3nFMGAT5ZnABTneGRQopk834.mp4
storage_upload_slave_by_filename
group_name=group2, remote_filename=M01/00/00/rBkmCl3nFMGAT5ZnABTneGRQopk834_big.mp4
source ip address: 172.25.38.10
file timestamp=2019-12-04 10:06:57
file size=1369976
file crc32=1683006105
example file url: http://172.25.38.10:8080/group2/M01/00/00/rBkmCl3nFMGAT5ZnABTneGRQopk834_big.mp4
```

通过上传了两个测试视频文件，一个分布在group1组内，一个分布在group2组内，在各个组内的每台机器上都存了一份该文件。上传完毕后给提供了一个URL，将URL粘贴至浏览器可以正常访问，即FastDFS部署完成。









































