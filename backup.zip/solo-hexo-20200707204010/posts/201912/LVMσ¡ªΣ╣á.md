title: LVM学习
date: '2019-12-26 17:38:05'
updated: '2019-12-26 17:38:29'
tags: [lvm, 虚拟化]
permalink: /articles/2019/12/26/1577353085137.html
---
![](https://img.hacpai.com/bing/20190529.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

* lvm的概念

lvm是逻辑盘卷管理（logical volume manager）的简称，它是Linux环境下对磁盘分区进行管理的一种机制，lvm是建立在硬盘和分区之上的一个逻辑层，来提高磁盘分区管理的灵活性。lvm最大的特点就是可以对磁盘进行动态管理；因为逻辑卷的大小是可以动态调整的，可伸缩性强，而且不会丢失现有的数据。使用system-config-lvm工具进行管理，boot分区不能使用lvm逻辑卷。

* lvm的工作原理

lvm就是通过将底层的物理硬盘抽象的封装起来，然后以逻辑卷的方式呈现给上层应用。在传统的磁盘管理机制中，我们的上层应用是直接访问文件系统，从而对底层的物理硬盘进行读取；而在lvm中，其通过对底层的硬件进行封装，当我们对底层的物理硬盘进行操作时，其不再是针对于分区进行操作，而是通过一个叫做逻辑卷的东西来对其进行底层的磁盘操作。

* 逻辑卷的组成

1. pv逻辑卷，将普通分区转换为物理卷会被分成若干个小块，每个块4M，方便用户进行扩展和收缩；
2. vg卷组，vg将位于多块硬盘分区进行统一管理，必须先创建物理卷后创建卷组；
3. lv逻辑卷，逻辑卷用于存储数据使用，逻辑卷必须在卷组的基础上创建；
![imagelvm.png](https://img.hacpai.com/file/2019/12/imagelvm-74131ec8.png)

先检查系统是否安装lvm

```
# rpm -qa|grep lvm 
lvm2-libs-2.02.185-2.el7_7.2.x86_64 
lvm2-2.02.185-2.el7_7.2.x86_64 
llvm-private-7.0.1-1.el7.x86_64
```

如果没有安装，则执行

```
# yum install lvm2 -y
```

  

手动添加一个容量为20GB的磁盘/dev/sdb。

对物理分区pv的操作有：

```
# pv
pvchange pvck pvcreate pvdisplay pvmove pvremove pvresize pvs pvscan
```

对卷组vg的操作有：

```
# vg
vgcfgbackup vgchange vgconvert vgdb vgexport vgimport vgmerge vgreduce vgrename vgscan vgcfgrestore vgck vgcreate vgdisplay vgextend vgimportclone vgmknodes vgremove vgs vgsplit
```

对逻辑卷lv的操作有：

```
# lv
lvchange lvcreate lvextend lvmconf lvmdiskscan lvmetad lvmsadc lvreduce lvrename lvs lvconvert lvdisplay lvm lvmconfig lvmdump lvmpolld lvmsar lvremove lvresize lvscan
```

敲出命令前缀tab就能全部显示出来。

```
功能/命令    物理卷管理     卷组管理     逻辑卷管理 
扫描          pvscan      vgscan       lvscan 
创建          pvcreate    vgcreate     lvcreate 
显示          pvdisplay   vgdisplay    lvdisplay 
删除          pvremove    vgremove     lvremove 
扩展                      vgextend     lvextend 
缩小                      vgreduce     lvreduce
```

* 创建一个物理卷

```
# pvcreate /dev/sdb 
Physical volume "/dev/sdb" successfully created.
```

* 创建卷组

```
# vgcreate aliez /dev/sdb 
Volume group "aliez" successfully created
```

卷组创建时，物理卷会被LVM以最小存储单元，也就是PE，分为一个个大小一样存储块。后面创建逻辑卷时，也会以LE为最小分配单元。由于内核限制，一个逻辑卷只会包含216个LE，如PE=LE=1MB，则一个LV最大容量为63356MB。PE,LE大小在卷组创建时确定，默认值为4MB。如果需要更改为1MB，则命令这样写：

```
# vgcreate 1MB aliez /dev/sdb
```

* 查看物理卷状态

```
# pvdisplay /dev/sdb
 --- Physical volume --- 
PV Name /dev/sdb 
VG Name aliez 
PV Size 20.00 GiB / not usable 4.00 MiB 
Allocatable yes 
PE Size 4.00 MiB 
Total PE 5119 
Free PE 5119 
Allocated PE 0 
PV UUID a1q5lk-FzeE-Xdxi-Qg1I-QhJf-iVGj-FlAy6t
```

* 查看卷组状态

```
# vgdisplay aliez
 --- Volume group --- 
VG Name aliez 
System ID 
Format lvm2 
Metadata Areas 1 
Metadata Sequence No 1 
VG Access read/write VG Status resizable 
MAX LV 0 
Cur LV 0 
Open LV 0 
Max PV 0 
Cur PV 1 
Act PV 1 
VG Size <20.00 GiB 
PE Size 4.00 MiB 
Total PE 5119 
Alloc PE / Size 0 / 0 
Free PE / Size 5119 / <20.00 GiB VG 
UUID XeeDLu-2wFO-9MC3-cLZf-33DP-tanJ-hpf4zr
```

* 创建逻辑卷

```
# lvcreate -L 10G -n lvs-01 aliez 
Logical volume "lvs-01" created.
```

在卷组aliez上创建名为lvs-01的逻辑卷。逻辑卷大小有两种指定方法：

1. 用-L参数显示指定大小；
2. 用-l参数指定该逻辑卷包含LE的数量（LE取默认值4MB）

```
# lvcreate -I 2560 -n lvs-01 aliez
```

上面命令创建的逻辑卷lvs-01大小也是10GB。

* 查看逻辑卷

```
# lvdisplay
 --- Logical volume --- 
LV Path /dev/aliez/lvs-01 
LV Name lvs-01 
VG Name aliez 
LV UUID KHNkEz-Dafa-aevk-UDIS-PoSN-5gqN-Orl63k 
LV Write Access read/write 
LV Creation host, time linux-node-03, 2019-12-26 11:41:04 +0800 
LV Status available # open 0 
LV Size 10.00 GiB 
Current LE 2560 
Segments 1 
Allocation inherit 
Read ahead sectors auto 
- currently set to 8192 
Block device 253:2
```

* 在逻辑卷上创建文件系统

```
# mkfs.ext4 /dev/aliez/lvs-01 
mke2fs 1.42.9 (28-Dec-2013) 
文件系统标签= 
OS type: Linux 
块大小=4096 (log=2) 
分块大小=4096 (log=2) 
Stride=0 blocks, Stripe width=0 blocks 
655360 inodes, 2621440 blocks 
131072 blocks (5.00%) reserved for the super user 
第一个数据块=0 
Maximum filesystem blocks=2151677952 
80 block groups 
32768 blocks per group, 32768 fragments per group 
8192 inodes per group 
Superblock backups stored on blocks: 
       32768, 98304, 163840, 229376, 294912, 819200, 884736, 1605632 
Allocating group tables: 完成 
正在写入inode表: 完成 
Creating journal (32768 blocks): 完成 
Writing superblocks and filesystem accounting information: 完成
```

* 挂载逻辑卷到目录

```
# mkdir /data 
# blkid /dev/aliez/lvs-01 
/dev/aliez/lvs-01: UUID="8ca745d0-38dd-4893-a21b-4f9cbfb51b9e" TYPE="ext4" 
# echo "UUID=8ca745d0-38dd-4893-a21b-4f9cbfb51b9e /data ext4 defaults 0 0" >> /etc/fstab # mount -a 
# df -h 
文件系统 容量 已用 可用 已用% 挂载点 
devtmpfs 2.0G 0 2.0G 0% /dev tmpfs 2.0G 0 2.0G 0% 
/dev/shm tmpfs 2.0G 13M 2.0G 1% /run tmpfs 2.0G 0 2.0G 0% /sys/fs/cgroup /dev/mapper/centos-root 17G 7.3G 9.6G 44% / /dev/sda2 1014M 158M 857M 16% /boot /dev/sda1 200M 12M 189M 6% /boot/efi 
tmpfs 394M 0 394M 0% /run/user/0 
/dev/mapper/aliez-lvs-01 10G 33M 10G 1% /data
```

* lvm在线扩展

A. vg空间足够的情况下

```
# lvs 
LV VG Attr LSize Pool Origin Data% Meta% Move Log Cpy%Sync Convert 
lvs-01 aliez -wi-ao---- 10.00g 
root centos -wi-ao---- 16.80g 
swap centos -wi-ao---- 2.00g
```

给/dev/aliez/lvs1226扩展500M空间

```
# lvextend -L +500M /dev/aliez/lvs-01 
Size of logical volume aliez/lvs1226 changed from 10.00 GiB (2560 extents) to <10.49 GiB (2685 extents). 
Logical volume aliez/lvs1226 successfully resized.
```

```
# lvs 
LV VG Attr LSize Pool Origin Data% Meta% Move Log Cpy%Sync Convert 
lvs-01 aliez -wi-ao---- <10.49g 
root centos -wi-ao---- 16.80g 
swap centos -wi-ao---- 2.00g
```

通过检查，扩容成功，但是通过df -h查看，空间还是没有任何变化，需要对文件系统进行扩容

```
# resize2fs /dev/aliez/lvs-01 
resize2fs 1.42.9 (28-Dec-2013) 
Filesystem at /dev/aliez/lvs-01 is mounted on /data; on-line resizing required old_desc_blocks = 2, new_desc_blocks = 2 
The filesystem on /dev/aliez/lvs-01 is now 2749440 blocks long. 
# df -h 文件系统 容量 已用 可用 已用% 挂载点 
devtmpfs 2.0G 0 2.0G 0% /dev tmpfs 2.0G 0 2.0G 0% 
/dev/shm tmpfs 2.0G 13M 2.0G 1% /run tmpfs 2.0G 0 2.0G 0% /sys/fs/cgroup /dev/mapper/centos-root 17G 7.3G 9.6G 44% / /dev/sda2 1014M 158M 857M 16% /boot /dev/sda1 200M 12M 189M 6% /boot/efi 
tmpfs 394M 0 394M 0% /run/user/0 
/dev/mapper/aliez-lvs--01 11G 41M 9.7G 1% /data
```

如果是xfs文件系统,用resize2fs /dev/aliez/lvs-01会报如下错误：

```
resize2fs: Bad magic number in super-block 当尝试打开 /dev/aliez/lvs-01 时 
找不到有效的文件系统超级块.
```

解决办法：

```
# xfs_growfs /dev/aliez/lvs-01
```

其他用法：

```
# esize2fs /dev/aliez/lvs-01　　               ＃更新文件系统的大小，即激活 
# resize2fs -f　/dev/aliez/lvs-01　500M　      ＃强制设置大小 
# dumpe2fs /dev/aliez/lvs-01 　　　            ＃查看ext系列文件系统
```

B.vg空间不够，需先扩展vg

```
# pvcreate /dev/sdg 
 Physical volume "/dev/sdg" successfully created. 
# vgextend aliez-01 /dev/sdg 
 Volume group "vgtest" successfully extended 
# vgs aliez-01
 VG #PV #LV #SN Attr VSize VFree 
aliez-01 1 1 0 wz--n- 19.98g 11.98g 

# lvextend -L 1G /dev/aliez-01/lvs-01 
Size of logical volume aliez-01/lvs-02 changed from 260.00 MiB (65 extents) to 1.00 GiB (256 extents).
Logical volume aliez-01/lvs-02 successfully resized. 
# lvs 
LV VG Attr LSize Pool Origin Data% Meta% Move Log Cpy%Sync Convert 
lvs-01 aliez-01 -wi-ao---- 12.00g
```

* 删除lvm

如果要彻底删除lvm，必须要和创建的时候的=顺序相反，即先卸载文件系统，然后删除lv，再删除vg，最后删除pv。

```
# umount /data 
# lvremove /dev/aliez/lvs-01
Do you really want to remove active logical volume aliez/lvs-01? [y/n]: y 
Logical volume "lvs-01" successfully removed 
# vgremove aliez 
Volume group "aliez" successfully removed 
# pvremove /dev/sdb 
Labels on physical volume "/dev/sdb" successfully wiped.
```

