title: php安装
date: '2019-12-11 23:35:41'
updated: '2019-12-11 23:35:41'
tags: [php, nginx, 运维, Solo]
permalink: /articles/2019/12/11/1576078541741.html
---
安装PHP lib库
```
# yum install zlib-devel libxml2-devel libjpeg-devel libjpeg-turbo-devel libiconv-devel -y
# yum install freetype-devel libpng-devel gd-devel libcurl-devel libxslt-devel libxslt-devel -y
```

下载libiconv包
```
# wget http://ftp.gnu.org/pub/gnu/libiconv/libiconv-1.16.tar.gz
```

安装libiconv
```
# mv libiconv-1.16.tar.gz /usr/local/src/
# cd /usr/local/src
# tar xf libiconv-1.16.tar.gz 
# cd libiconv-1.16
# ./configure --prefix=/usr/local/libiconv
# make
# make install 
```

安装依赖
```
# yum install libmcrypt-devel mhash mcrypt sqlite-devel -y
# yum install https://dl.fedoraproject.org/pub/epel/7/x86_64/Packages/o/oniguruma-5.9.5-3.el7.x86_64.rpm
# yum install https://dl.fedoraproject.org/pub/epel/7/x86_64/Packages/o/oniguruma-devel-5.9.5-3.el7.x86_64.rpm
```

下载php
```
# wget https://www.php.net/distributions/php-7.4.0.tar.gz
```

编译安装
```
# tar xf php-7.4.0.tar.gz
# cd php-7.4.0
# ./configure \
--prefix=/usr/local/php \
--enable-mysqlnd  \
--with-mysqli=mysqlnd \
--with-pdo-mysql=mysqlnd \
--with-iconv-dir=/usr/local/libiconv \
--with-freetype-dir \
--with-jpeg-dir \
--with-png-dir \
--with-zlib \
--with-libxml-dir=/usr \
--enable-xml \
--disable-rpath \
--enable-bcmath \
--enable-shmop \
--enable-sysvsem \
--enable-inline-optimization \
--with-curl \
--enable-mbregex \
--enable-fpm \
--enable-mbstring \
--with-gd \
--with-openssl \
--with-mhash \
--enable-pcntl \
--enable-sockets \
--with-xmlrpc \
--enable-soap \
--enable-short-tags \
--enable-static \
--with-xsl \
--with-fpm-user=nginx \
--with-fpm-group=nginx \
--enable-ftp \
--enable-opcache=no
```
编译&&编译安装
```
# make
# make install
```

配置、启动
```
# ll /usr/local/src/php-7.4.0/php.ini-*
# cp /usr/local/src/php-7.4.0/php.ini-development /usr/local/php/lib/php.ini
# cp /usr/local/php/etc/php-fpm.conf.default /usr/local/php/etc/php-fpm.conf
# cp /usr/local/php/etc/php-fpm.d/www.conf.default /usr/local/php/etc/php-fpm.d/www.conf
# cp /usr/local/src/php-7.4.0/sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm
# chmod +x /etc/init.d/php-fpm
# /etc/init.d/php-fpm start
```

nginx配置
```
# vim nginx.conf
server {
        listen 80 backlog=8192;
        server_name  localhost;
        location / {
            root   html/wordpress;
            index  index.php index.html index.htm;
        }
        location ~ .*\.(php|php5)?$ {
            root html/wordpress;
            fastcgi_pass  127.0.0.1:9000;
            fastcgi_index index.php;
            include fastcgi.conf;
        }
    access_log  /var/log/nginx/access.log  access;
}
```











