title: centos7修改服务器时间
date: '2020-01-20 14:34:56'
updated: '2020-02-26 21:00:44'
tags: [centos, ntp, ntpdate]
permalink: /articles/2020/01/20/1579502096108.html
---
![](https://img.hacpai.com/bing/20190722.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

安装在虚拟机上的CentOS7的时间分为系统时间和硬件时间。二者都修改，重启系统（init 6 )才会永久生效。

  

修改步骤如下

  

* 查看当前系统时间 date
* 修改当前系统时间 date -s "2020-01-12 19:10:30
* 查看硬件时间 hwclock --show
* 修改硬件时间 hwclock --set --date "2020-01-12 19:10:30"
* 同步系统时间和硬件时间 hwclock --hctosys
* 保存时钟 clock -w
* 再次date查看，发现时间已经修改了

也可以用下面的方法进行修改：
```
##修改时区为亚洲上海
# timedatectl set-timezone Asia/Shanghai
##查看硬件时间
# hwclock --show
##保存时钟
# clock  -w
##同步系统时间和硬件时间
# hwclock --systohc
##时间同步
# ntpdate ntp1.aliyun.com
```
