title: Harbor安装部署
date: '2020-01-21 14:11:29'
updated: '2020-01-21 14:14:21'
tags: [harbor, registry, docker, docker-compose]
permalink: /articles/2020/01/21/1579587088838.html
---
![](https://img.hacpai.com/bing/20190401.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

参考文档：https://blog.zhenglin.work/docker/harbor-install.html
官方参考文档：https://github.com/goharbor/harbor/blob/release-1.10.0/docs/installation_guide.md
部署参考文档：https://www.cnblogs.com/wangzhangtao/p/12076816.html



开启安装包缓存，为离线安装做准备（忽略）
``` 
# sed -i "s/keepcache=0/keepcache=1/g" /etc/yum.conf
```
缓存安装包在/var/cache/yum/x86_64目录下
安装docker-ce官方repo源

``` 
# yum-config-manager  --add-repo https://download.docker.com/linux/centos/docker-ce.repo
``` 
这个文件存放在/etc/yum.repos.d
安装docker-ce

``` 
# yum -y install docker-ce docker-ce-cli containerd.io
``` 
启动docker服务

``` 
# systemctl start docker
``` 
查看docker信息

``` 
# docker info
Client:
 Debug Mode: false
Server:
 Containers: 0
  Running: 0
  Paused: 0
  Stopped: 0
 Images: 0
 Server Version: 19.03.5
 Storage Driver: overlay2
  Backing Filesystem: xfs
  Supports d_type: true
  Native Overlay Diff: true
 Logging Driver: json-file
 Cgroup Driver: cgroupfs
 Plugins:
  Volume: local
  Network: bridge host ipvlan macvlan null overlay
  Log: awslogs fluentd gcplogs gelf journald json-file local logentries splunk syslog
 Swarm: inactive
 Runtimes: runc
 Default Runtime: runc
 Init Binary: docker-init
 containerd version: b34a5c8af56e510852c35414db4c1f4fa6172339
 runc version: 3e425f80a8c931f88e6d94a8c831b9d5aa481657
 init version: fec3683
 Security Options:
  seccomp
   Profile: default
 Kernel Version: 3.10.0-1062.el7.x86_64
 Operating System: CentOS Linux 7 (Core)
 OSType: linux
 Architecture: x86_64
 CPUs: 8
 Total Memory: 15.51GiB
 Name: xuetangx-node-01
 ID: JNA3:DDQB:HN57:563L:ZUB3:IQAE:NCQQ:2D5Y:5SVE:DOEV:LNFK:PHPG
 Docker Root Dir: /var/lib/docker
 Debug Mode: false
 Registry: https://index.docker.io/v1/
 Labels:
 Experimental: false
 Insecure Registries:
  127.0.0.0/8
 Live Restore Enabled: false

WARNING: bridge-nf-call-iptables is disabled
WARNING: bridge-nf-call-ip6tables is disabled!! 
``` 
发现有两个警告

``` 
# echo "net.bridge.bridge-nf-call-ip6tables = 1" >>/etc/sysctl.conf
# echo "net.bridge.bridge-nf-call-iptables = 1" >>/etc/sysctl.conf
# sysctl -p
``` 

``` 
# docker version
Client: Docker Engine - Community
 Version:           19.03.5
 API version:       1.40
 Go version:        go1.12.12
 Git commit:        633a0ea
 Built:             Wed Nov 13 07:25:41 2019
 OS/Arch:           linux/amd64
 Experimental:      false

Server: Docker Engine - Community
 Engine:
  Version:          19.03.5
  API version:      1.40 (minimum version 1.12)
  Go version:       go1.12.12
  Git commit:       633a0ea
  Built:            Wed Nov 13 07:24:18 2019
  OS/Arch:          linux/amd64
  Experimental:     false
 containerd:
  Version:          1.2.10
  GitCommit:        b34a5c8af56e510852c35414db4c1f4fa6172339
 runc:
  Version:          1.0.0-rc8+dev
  GitCommit:        3e425f80a8c931f88e6d94a8c831b9d5aa481657
 docker-init:
  Version:          0.18.0
  GitCommit:        fec3683
``` 
至此，docker-ce安装完毕，接下来安装harbor

首先确保你的系统有安装wget命令，如果没有，则yum install wget -y执行安装，该安装包我已缓存；
下载harbor 1.10版本离线安装包

``` 
# cd /usr/local/src
# wget https://github.com/goharbor/harbor/releases/download/v1.10.0/harbor-offline-installer-v1.10.0.tgz
``` 
解压、修改配置文件

``` 
# tar xf harbor-offline-installer-v1.10.0.tgz 
# cd harbor
# ll
总用量 629904
-rw-r--r--. 1 root root      3398 12月  6 12:02 common.sh
-rw-r--r--. 1 root root 644985680 12月  6 12:02 harbor.v1.10.0.tar.gz
-rw-r--r--. 1 root root      5882 12月  6 12:02 harbor.yml
-rwxr-xr-x. 1 root root      2284 12月  6 12:02 install.sh
-rw-r--r--. 1 root root     11347 12月  6 12:02 LICENSE
-rwxr-xr-x. 1 root root      1749 12月  6 12:02 prepare
# vim harbor.yml
hostname: 192.168.9.222
##我们harbor使用的是http协议，所以将https的选项全部关闭即可；
``` 
安装部署harbor前请先确保你的系统安装了docker-compose，如果没有安装，按照下面的步骤安装，如果安装了，则直接忽略掉这一步；

``` 
# curl -L "https://github.com/docker/compose/releases/download/1.25.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
# chmod +x /usr/local/bin/docker-compose 
# ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
# docker-compose --version
docker-compose version 1.25.0, build 0a186604

``` 
安装部署harbor服务

``` 
# /usr/local/src/harbor/install.sh 

[Step 0]: checking if docker is installed ...

Note: docker version: 19.03.5

[Step 1]: checking docker-compose is installed ...

Note: docker-compose version: 1.25.0

[Step 2]: loading Harbor images ...
47a4bb1cfbc7: Loading layer [==================================================&gt;]  34.26MB/34.26MB
a9f6374f6301: Loading layer [==================================================&gt;]   9.05MB/9.05MB
bcc00f109225: Loading layer [==================================================&gt;]  6.239MB/6.239MB
e8ab93b98902: Loading layer [==================================================&gt;]  14.61MB/14.61MB
9693a5513be0: Loading layer [==================================================&gt;]  28.24MB/28.24MB
b7d7d682bc6d: Loading layer [==================================================&gt;]  22.02kB/22.02kB
d900ce1515a6: Loading layer [==================================================&gt;]  49.09MB/49.09MB
Loaded image: goharbor/notary-signer-photon:v0.6.1-v1.10.0
c213392443fe: Loading layer [==================================================&gt;]  73.37MB/73.37MB
96da3f81a9fa: Loading layer [==================================================&gt;]   42.3MB/42.3MB
6d5cecb71914: Loading layer [==================================================&gt;]   2.56kB/2.56kB
0176040eb813: Loading layer [==================================================&gt;]  1.536kB/1.536kB
c3ef530b4890: Loading layer [==================================================&gt;]  166.4kB/166.4kB
4beac5b37ba2: Loading layer [==================================================&gt;]  3.006MB/3.006MB
Loaded image: goharbor/prepare:v1.10.0
b74d8257d4e7: Loading layer [==================================================&gt;]  12.83MB/12.83MB
84600f9f0741: Loading layer [==================================================&gt;]  41.86MB/41.86MB
ffe062536c6c: Loading layer [==================================================&gt;]  5.632kB/5.632kB
ea7f137ea115: Loading layer [==================================================&gt;]  40.45kB/40.45kB
3e4a0845adac: Loading layer [==================================================&gt;]  41.86MB/41.86MB
Loaded image: goharbor/harbor-core:v1.10.0
69e43242ff64: Loading layer [==================================================&gt;]  50.39MB/50.39MB
181ea859832f: Loading layer [==================================================&gt;]  3.584kB/3.584kB
8177cfc3d4f6: Loading layer [==================================================&gt;]  3.072kB/3.072kB
d6a67476a798: Loading layer [==================================================&gt;]   2.56kB/2.56kB
ba6e88638645: Loading layer [==================================================&gt;]  3.072kB/3.072kB
6f4e810775fe: Loading layer [==================================================&gt;]  3.584kB/3.584kB
68a002a96794: Loading layer [==================================================&gt;]  12.29kB/12.29kB
Loaded image: goharbor/harbor-log:v1.10.0
badcf9296df7: Loading layer [==================================================&gt;]  9.056MB/9.056MB
cf547160f0cb: Loading layer [==================================================&gt;]  3.584kB/3.584kB
6ea8d6e27cc8: Loading layer [==================================================&gt;]  3.072kB/3.072kB
d5bbe5fd758e: Loading layer [==================================================&gt;]  21.76MB/21.76MB
89671f09ee94: Loading layer [==================================================&gt;]  22.59MB/22.59MB
Loaded image: goharbor/registry-photon:v2.7.1-patch-2819-2553-v1.10.0
731b3ddd17ae: Loading layer [==================================================&gt;]  16.04MB/16.04MB
097c19c25f23: Loading layer [==================================================&gt;]  28.24MB/28.24MB
e9fd9ba28814: Loading layer [==================================================&gt;]  22.02kB/22.02kB
d4da382b94f0: Loading layer [==================================================&gt;]  50.52MB/50.52MB
Loaded image: goharbor/notary-server-photon:v0.6.1-v1.10.0
c2d9cf7a4eaf: Loading layer [==================================================&gt;]  9.056MB/9.056MB
7ff1181fe317: Loading layer [==================================================&gt;]   9.71MB/9.71MB
bbef02a499c4: Loading layer [==================================================&gt;]   9.71MB/9.71MB
Loaded image: goharbor/clair-adapter-photon:v1.0.1-v1.10.0
86340c56281e: Loading layer [==================================================&gt;]  9.055MB/9.055MB
239a2501714d: Loading layer [==================================================&gt;]  42.31MB/42.31MB
82cb5fb66ee1: Loading layer [==================================================&gt;]  3.072kB/3.072kB
5df190fa4c4a: Loading layer [==================================================&gt;]  3.584kB/3.584kB
1ad5a86de000: Loading layer [==================================================&gt;]  43.14MB/43.14MB
Loaded image: goharbor/chartmuseum-photon:v0.9.0-v1.10.0
a2ffdaaa3434: Loading layer [==================================================&gt;]  63.56MB/63.56MB
5745ac9e0297: Loading layer [==================================================&gt;]  54.44MB/54.44MB
47a40f68074f: Loading layer [==================================================&gt;]  5.632kB/5.632kB
3480ec848416: Loading layer [==================================================&gt;]  2.048kB/2.048kB
6b1347c012b5: Loading layer [==================================================&gt;]   2.56kB/2.56kB
8d58ae62dfff: Loading layer [==================================================&gt;]   2.56kB/2.56kB
b244f429f353: Loading layer [==================================================&gt;]   2.56kB/2.56kB
9e6aa8541fd4: Loading layer [==================================================&gt;]  10.24kB/10.24kB
Loaded image: goharbor/harbor-db:v1.10.0
07efa003923d: Loading layer [==================================================&gt;]  9.056MB/9.056MB
f58d9d3ffa81: Loading layer [==================================================&gt;]  3.584kB/3.584kB
46a1832765ca: Loading layer [==================================================&gt;]  21.76MB/21.76MB
01e5ce40973a: Loading layer [==================================================&gt;]  3.072kB/3.072kB
415ae2dee656: Loading layer [==================================================&gt;]  8.662MB/8.662MB
676dc2d0e966: Loading layer [==================================================&gt;]  31.24MB/31.24MB
Loaded image: goharbor/harbor-registryctl:v1.10.0
db95a8bece9e: Loading layer [==================================================&gt;]  78.32MB/78.32MB
9a0924a25b60: Loading layer [==================================================&gt;]  3.072kB/3.072kB
7cb7e9d75e7d: Loading layer [==================================================&gt;]   59.9kB/59.9kB
7c0cc7ba0eb4: Loading layer [==================================================&gt;]  61.95kB/61.95kB
Loaded image: goharbor/redis-photon:v1.10.0
48cda078e98d: Loading layer [==================================================&gt;]  10.89MB/10.89MB
Loaded image: goharbor/nginx-photon:v1.10.0
9ea2dad46741: Loading layer [==================================================&gt;]  10.89MB/10.89MB
0da7797cc45f: Loading layer [==================================================&gt;]  7.696MB/7.696MB
72633f284549: Loading layer [==================================================&gt;]  223.2kB/223.2kB
0fe7226e7f5e: Loading layer [==================================================&gt;]  195.1kB/195.1kB
09d13331e39d: Loading layer [==================================================&gt;]  15.36kB/15.36kB
0911c8ab4812: Loading layer [==================================================&gt;]  3.584kB/3.584kB
Loaded image: goharbor/harbor-portal:v1.10.0
f3967aa0de5f: Loading layer [==================================================&gt;]  115.8MB/115.8MB
ef07a35b449d: Loading layer [==================================================&gt;]  12.14MB/12.14MB
d388cc1fc249: Loading layer [==================================================&gt;]  3.072kB/3.072kB
8afe0ff3e4d1: Loading layer [==================================================&gt;]  49.15kB/49.15kB
1ac3d3c632b4: Loading layer [==================================================&gt;]  3.584kB/3.584kB
5a06625202c0: Loading layer [==================================================&gt;]  13.02MB/13.02MB
Loaded image: goharbor/clair-photon:v2.1.1-v1.10.0
0039915754c6: Loading layer [==================================================&gt;]  12.83MB/12.83MB
8b5f7c0672e5: Loading layer [==================================================&gt;]  48.59MB/48.59MB
Loaded image: goharbor/harbor-jobservice:v1.10.0
62b223a46a15: Loading layer [==================================================&gt;]  34.29MB/34.29MB
f62d30545b31: Loading layer [==================================================&gt;]    338MB/338MB
ce4bd5384c87: Loading layer [==================================================&gt;]  135.2kB/135.2kB
Loaded image: goharbor/harbor-migrator:v1.10.0

[Step 3]: preparing environment ...

[Step 4]: preparing harbor configs ...
prepare base dir is set to /usr/local/src/harbor
WARNING:root:WARNING: HTTP protocol is insecure. Harbor will deprecate http protocol in the future. Please make sure to upgrade to https
Generated configuration file: /config/log/logrotate.conf
Generated configuration file: /config/log/rsyslog_docker.conf
Generated configuration file: /config/nginx/nginx.conf
Generated configuration file: /config/core/env
Generated configuration file: /config/core/app.conf
Generated configuration file: /config/registry/config.yml
Generated configuration file: /config/registryctl/env
Generated configuration file: /config/db/env
Generated configuration file: /config/jobservice/env
Generated configuration file: /config/jobservice/config.yml
Generated and saved secret to file: /secret/keys/secretkey
Generated certificate, key file: /secret/core/private_key.pem, cert file: /secret/registry/root.crt
Generated configuration file: /compose_location/docker-compose.yml
Clean up the input dir


[Step 5]: starting Harbor ...
Creating network "harbor_harbor" with the default driver
Creating harbor-log ... done
Creating harbor-portal ... done
Creating registryctl   ... done
Creating registry      ... done
Creating harbor-db     ... done
Creating redis         ... done
Creating harbor-core   ... done
Creating harbor-jobservice ... done
Creating nginx             ... done
✔ ----Harbor has been installed and started successfully.----
```
检查

``` 
# docker images
REPOSITORY                      TAG                              IMAGE ID            CREATED             SIZE
goharbor/chartmuseum-photon     v0.9.0-v1.10.0                   c8c98d2ac22b        6 weeks ago         128MB
goharbor/harbor-migrator        v1.10.0                          9dd0c9228c79        6 weeks ago         362MB
goharbor/redis-photon           v1.10.0                          6df66e5c1ca7        6 weeks ago         111MB
goharbor/clair-adapter-photon   v1.0.1-v1.10.0                   4bdc58f374c2        6 weeks ago         61.6MB
goharbor/clair-photon           v2.1.1-v1.10.0                   435d235c5000        6 weeks ago         171MB
goharbor/notary-server-photon   v0.6.1-v1.10.0                   c7934c32e873        6 weeks ago         143MB
goharbor/notary-signer-photon   v0.6.1-v1.10.0                   bb1a762155ab        6 weeks ago         140MB
goharbor/harbor-registryctl     v1.10.0                          c550280445e6        6 weeks ago         104MB
goharbor/registry-photon        v2.7.1-patch-2819-2553-v1.10.0   2115e08fa399        6 weeks ago         86.5MB
goharbor/nginx-photon           v1.10.0                          f7ed614c3abc        6 weeks ago         44MB
goharbor/harbor-log             v1.10.0                          fb15f6772e9a        6 weeks ago         82.3MB
goharbor/harbor-jobservice      v1.10.0                          d6d4f2b125f6        6 weeks ago         142MB
goharbor/harbor-core            v1.10.0                          f3a3065b3af2        6 weeks ago         128MB
goharbor/harbor-portal          v1.10.0                          fbaeb1fdacad        6 weeks ago         52.1MB
goharbor/harbor-db              v1.10.0                          634404a417cf        6 weeks ago         148MB
goharbor/prepare                v1.10.0                          927062458494        6 weeks ago         149MB

# docker ps 
CONTAINER ID        IMAGE                                                     COMMAND                  CREATED             STATUS                   PORTS                       NAMES
0692300414a5        goharbor/nginx-photon:v1.10.0                             "nginx -g 'daemon of…"   3 minutes ago       Up 3 minutes (healthy)   0.0.0.0:80-&gt;8080/tcp        nginx
86a44cd9d52e        goharbor/harbor-jobservice:v1.10.0                        "/harbor/harbor_jobs…"   3 minutes ago       Up 3 minutes (healthy)                               harbor-jobservice
2de0522e639c        goharbor/harbor-core:v1.10.0                              "/harbor/harbor_core"    3 minutes ago       Up 3 minutes (healthy)                               harbor-core
9d2682ee291c        goharbor/redis-photon:v1.10.0                             "redis-server /etc/r…"   3 minutes ago       Up 3 minutes (healthy)   6379/tcp                    redis
537dda14c4f7        goharbor/registry-photon:v2.7.1-patch-2819-2553-v1.10.0   "/home/harbor/entryp…"   3 minutes ago       Up 3 minutes (healthy)   5000/tcp                    registry
926fe8a01eee        goharbor/harbor-db:v1.10.0                                "/docker-entrypoint.…"   3 minutes ago       Up 3 minutes (healthy)   5432/tcp                    harbor-db
57a189529bf2        goharbor/harbor-registryctl:v1.10.0                       "/home/harbor/start.…"   3 minutes ago       Up 3 minutes (healthy)                               registryctl
97373d59b5d4        goharbor/harbor-portal:v1.10.0                            "nginx -g 'daemon of…"   3 minutes ago       Up 3 minutes (healthy)   8080/tcp                    harbor-portal
1ffcb1996d2e        goharbor/harbor-log:v1.10.0                               "/bin/sh -c /usr/loc…"   3 minutes ago       Up 3 minutes (healthy)   127.0.0.1:1514-&gt;10514/tcp   harbor-log
``` 
在浏览器输入http://192.168.9.222
用户名：admin
密码：Harbor12345
注意：初次登陆之后记得修改密码！！！
![harbor.png](https://img.hacpai.com/file/2020/01/harbor-b8e7a191.png)

