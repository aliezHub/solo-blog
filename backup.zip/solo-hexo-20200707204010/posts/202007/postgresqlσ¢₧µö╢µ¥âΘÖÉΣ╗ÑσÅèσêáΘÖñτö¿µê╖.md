title: postgresql回收权限以及删除用户
date: '2020-07-07 10:48:35'
updated: '2020-07-07 10:48:35'
tags: [postgresql]
permalink: /articles/2020/07/07/1594090115322.html
---
![](https://img.hacpai.com/bing/20190121.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


1. 回收schema的usage权限
```
revoke USAGE ON SCHEMA public from user_name;
```

2. 回收public下所有表的查询权限：
```
revoke SELECT ON ALL TABLES IN SCHEMA public from user_name;
```

3. 回收public下所有序列的查询权限
```
revoke SELECT ON ALL SEQUENCES IN SCHEMA public from user_name;
```

4. 回收默认权限
```
ALTER DEFAULT PRIVILEGES IN SCHEMA public revoke SELECT ON TABLES from user_name;
```

5. 关闭数据库连接权限
```
revoke CONNECT ON DATABASE db_name from user_name;
```

6. 关闭默认只读事务设置
```
alter user user_name set default_transaction_read_only=off;
```

7. 查看权限是否为空了
```
\ddp
```

8. 通过管理员删除user_name用户：
```
drop user user_name;
```

