title: postgresql创建一个只读用户
date: '2020-07-07 10:44:37'
updated: '2020-07-07 10:44:37'
tags: [postgresql]
permalink: /articles/2020/07/07/1594089877677.html
---
![](https://img.hacpai.com/bing/20180321.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


1. 创建用户
```
CREATE USER user_name WITH ENCRYPTED PASSWORD 'password';
```

2. 设置只读事务
```
alter user user_name set default_transaction_read_only=on;
```

3. 赋予指定数据库权限
```
GRANT CONNECT ON DATABASE db_name to user_name;
```

4. 进入指定数据库
--在工具中进入数据库或命令行下：
```
\c db_name
```

5. 把当前库现有的所有在public这个schema下的表的使用权限赋给用户
```
GRANT USAGE ON SCHEMA public to user_name;
```

6. 默认把当前库之后新建在public这个schema下的表的使用权限赋给用户
```
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO user_name;
```

7. 赋予用户public下的序列的查看权
```
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO user_name;
```

8. 赋予用户public下的表的select权
```
GRANT SELECT ON ALL TABLES IN SCHEMA public TO user_name;
```

